# 来源卡 - SRC008

## 基本信息

| 字段 | 内容 |
|------|------|
| **来源编号** | SRC008 |
| **标题** | Phase-locked auditory pulse stimulation at home enhancing slow sleep waves: A pilot real-world study |
| **来源类型** | 论文（预印本） |
| **作者** | Guannan Xi, Xin Zheng, Anchen Gao, Siyang Huang, Huijie Lei, Jing Ding, Qianqian Zhang, Jian Jiang* |
| **机构归属** | 1Shanghai QuanLan Technology Co., Ltd; 2Department of Neurology, Zhongshan Hospital, Fudan University |
| **发布日期** | 2023-07-06 |
| **采集日期** | 2026-10-09 |
| **URL/DOI** | https://doi.org/10.1101/2023.07.02.23292083 |
| **所属方向** | R&D |
| **核验状态** | ✅ 已提取全文（20页，37,251字符） |

## 研究概述

**研究目的**：评估居家环境下基于LANMAO设备的锁相听觉脉冲刺激（PLAS）对增强慢波睡眠（SWS）的效果

**研究设计**：被试内设计（within-subject design），STIM vs SHAM对比

**样本量**：6名受试者（平均年龄29±4.2岁，3名男性）

## 关键观点

### 1. 设备描述（方法部分）
- **设备名称**：LANMAO device（QuanLan Technology Co., LTD, CHINA）
- **设备组成**：两个蓝牙连接部件——EEG记录仪和接收器
- **刺激算法**：部署在接收器上的闭环锁相算法
- **工作原理**：
  - 检测SWS阶段和每个慢波的过零时间
  - 在奇数慢波施加声学刺激（STIM）
  - 在偶数慢波不施加刺激（SHAM）

### 2. 研究方法
- **研究设计**：被试内设计（within-subject design）
- **研究环境**：居家环境（home setting）
- **受试者**：6名（平均年龄29±4.2岁，3名男性）
- **入组标准**：
  1. 规律一致的睡眠习惯
  2. 无睡眠、精神或神经系统疾病史
  3. 无可能导致睡眠障碍的身体疾病
- **伦理审批**：复旦大学附属中山医院伦理委员会（批准号：SK2020-005）

### 3. 核心结果（摘要）

#### 效果指标
PLAS在STIM条件下相比SHAM条件，显著增强了以下指标：
- **慢波活动（SWA）**
- **theta活动**
- **alpha活动**
- **快纺锤波（fast spindle）活动**
- **慢纺锤波（slow spindle）活动**

### 4. 研究结论
> "These results indicated that the capacity of PLAS, based on LANMAO device, could enhance the SWA in home setting. Our findings shed lights on the wide application of home-based deep sleep intervention."

### 5. 关键词
phase-locked auditory stimulation; slow-wave activity; home setting; wearable EEG device

## 支持片段与原文位置

### 片段1：研究背景
> "Deep sleep, also known as slow-wave sleep (SWS), is essential for maintaining good health and is characterized by electroencephalographic (EEG) slow-wave activity (SWA). The use of phase-locked auditory stimulation (PLAS) to enhance SWA has emerged as a promising approach. However, the effectiveness of home-based PLAS has not yet been fully established."
- **原文位置**：Page 1, Abstract - Background

### 片段2：研究方法
> "We used a newly developed wearable EEG device, called LANMAO, to record sleeping EEG signals and synchronize acoustic tones with SWA. We employed a within-subject design to investigate whether acoustic stimulation could increase SWA in a home setting using six subjects (mean age: 29±4.2 years, 3 males)."
> "we applied acoustic stimulation (STIM) on odd-numbered slow waves and no stimulation (SHAM) on even-numbered slow waves."
- **原文位置**：Page 1-2, Abstract - Method

### 片段3：核心结果
> "The PLAS significantly enhanced SWA, theta, alpha, fast spindle and slow spindle activity on STIM condition compare to SHAM condition across all subjects in home setting."
- **原文位置**：Page 2, Abstract - Results

### 片段4：设备描述
> "This device consists of two Bluetooth-connected parts: an EEG recorder and a receiver. PLAS was activated by an algorithm deployed in the receiver, which detected SWS stage and the cross-zero time of each slow wave based on the signals from the EEG recorder."
- **原文位置**：Page 3-4, Introduction

### 片段5：受试者信息
> "A total of 6 subjects were recruited. The following enrollment criteria were applied: (1) having consistent and regular sleep habits, (2) no history of sleep, psychiatric or neurological disorders, and (3) no physical illnesses that could cause sleep disorders."
- **原文位置**：Page 4, Method - Participants

## 适用范围

- **地区**：中国大陆（上海）
- **对象**：6名健康成人受试者（平均年龄29±4.2岁，3名男性）
- **时间**：2023年7月（论文发布日期）
- **监测信号类型**：
  - 可穿戴EEG（单通道，推测为额叶）
  - 声学刺激（锁相听觉脉冲）
- **效果指标**：
  - 慢波活动（SWA）显著增强
  - theta、alpha活动增强
  - 快/慢纺锤波活动增强

## 局限

### ⚠️ 重要局限

1. **预印本，未经同行评审**：
   - 该论文为medRxiv预印本，**未经同行评审**
   - 研究质量和结论可靠性未经独立验证
   - 不应作为临床实践的指导依据

2. **厂商作者主导，存在利益冲突**：
   - **第一单位**：Shanghai QuanLan Technology Co., Ltd（上海全澜科技有限公司）
   - **通讯作者**：Jian Jiang，上海全澜科技有限公司
   - **第二单位**：Department of Neurology, Zhongshan Hospital, Fudan University（复旦大学附属中山医院神经内科）
   - **关键问题**：研究由产品公司作者主导，属于**厂商自研验证**而非独立第三方验证
   - **利益冲突**：作者可能从产品商业化中获益，研究结果可能存在偏倚

3. **样本量极小**：
   - 仅6名受试者（3男3女），样本量极小
   - 平均年龄29±4.2岁，受试者为年轻健康成人
   - 结果可能不稳定，需要更大样本验证

4. **受试者代表性不足**：
   - 入组标准排除了有睡眠障碍、精神疾病史者
   - 受试者为健康年轻人，不代表失眠患者或老年人群
   - 效果在目标用户群体中可能不同

5. **研究设计局限**：
   - 被试内设计，STIM vs SHAM对比
   - 仅评估单次干预效果
   - 未说明是否采用盲法（受试者是否知道STIM/SHAM条件）

6. **效果指标不完整**：
   - 仅报告了SWA、theta、alpha、纺锤波等频段活动增强
   - 未报告具体的效应量（effect size）或统计显著性水平
   - 未报告主观睡眠质量评估

7. **长期效果未知**：
   - 仅评估单次干预的急性效果
   - 未评估多次干预的累积效果或长期安全性

## 备注

该论文为基于LANMAO设备的锁相听觉脉冲刺激（PLAS）在居家环境下增强慢波睡眠的试点研究，**但为厂商自研验证，未经独立第三方验证**。

**与SRC001的关系**：SRC001产品手册第8页引用该论文作为"居家环境下慢波增强效果"的验证证据

**与SRC007的关系**：
- SRC007：LANMAO设备与PSG对比验证（7人，睡眠分期准确性）
- SRC008：LANMAO设备闭环声刺激效果验证（6人，慢波增强效果）
- 两篇论文均为同一公司（上海全澜科技）作者主导

**正确引用方式**：
> "澜猫睡眠X8产品手册引用了一项居家环境下慢波增强效果的试点研究（SRC008），报告显示锁相听觉脉冲刺激（PLAS）显著增强了慢波活动、theta、alpha和纺锤波活动。但需注意，该研究为厂商（上海全澜科技）作者主导的预印本，未经同行评审，样本量仅6人（健康年轻人），存在利益冲突，需独立第三方验证。"

---
*创建时间：2026-10-09 | 来源卡状态：✅ 已提取全文*