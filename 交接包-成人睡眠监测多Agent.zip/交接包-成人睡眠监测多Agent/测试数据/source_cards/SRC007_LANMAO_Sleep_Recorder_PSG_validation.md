# 来源卡 - SRC007

## 基本信息

| 字段 | 内容 |
|------|------|
| **来源编号** | SRC007 |
| **标题** | A wearable EEG device: LANMAO Sleep Recorder compared to polysomnography in terms of EEG recording and sleep analysis |
| **来源类型** | 论文（预印本） |
| **作者** | Xin Zheng, Guannan Xi, Huijie Lei, Dongbin Lyu, Yu Zhang, Chengmei Yuan, Anchen Gao, Siyang Huang, Jian Jiang* |
| **机构归属** | 1Shanghai Quanlan Technology Co., Ltd; 2Shanghai Mental Health Center, Shanghai Jiao Tong University School of Medicine |
| **发布日期** | 2023-05-30 |
| **采集日期** | 2026-10-09 |
| **URL/DOI** | https://doi.org/10.1101/2023.05.30.23290376 |
| **所属方向** | R&D |
| **核验状态** | ✅ 已提取全文（19页，46,285字符） |

## 研究概述

**研究目的**：评估可穿戴EEG设备LANMAO Sleep Recorder在EEG记录和睡眠分期算法方面与PSG金标准的一致性

**研究设计**：对比验证研究（LANMAO vs PSG）

**样本量**：7名中国成人受试者

## 关键观点

### 1. 设备描述（方法部分）
- **设备名称**：LANMAO Sleep Recorder（LM）
- **设备类型**：可穿戴额贴式EEG设备
- **通道配置**：单通道额叶EEG（FP1-FP2）
- **采样率**：500Hz（来自SRC001产品手册）
- **睡眠分期算法**：基于LightGBM框架
- **配套功能**：闭环声刺激（来自SRC001产品手册）

### 2. 研究方法
- **对比标准**：PSG金标准（多导睡眠图）
- **对比内容**：
  1. 原始信号一致性：相对频谱功率（relative spectral power）和Pearson相关系数
  2. 睡眠分期算法性能：与专家分期结果对比
- **频段分析**：delta、theta、alpha、beta、gamma等多个频段

### 3. 核心结果（摘要）

#### 信号一致性
- **Pearson相关系数**：各睡眠阶段多频段相对频谱功率的相关系数范围为 **0.7613-0.8816**
- **最强相关**：delta波（r=0.8816）

#### 睡眠分期性能
- **总体F1-Score**：**84.03%**
- **各类F1-Score**：
  - Wake（清醒）：93.67%
  - REM（快速眼动）：87.23%
  - Light Sleep（浅睡）：72.10%
  - Deep Sleep（深睡）：82.82%

### 4. 研究结论
> "The results suggest that the EEG recorded by the LANMAO Sleep Recorder is precise and valid, and its automated sleep staging algorithm can accurately perform sleep staging with high accuracy. Therefore, in specific scenarios such as the home environment, LANMAO devices can work as a promising PSG alternative for sleep monitoring."

### 5. 关键词
sleep staging; forehead EEG recorder; wearable; machine learning

## 支持片段与原文位置

### 片段1：研究目的
> "Polysomnography (PSG) is the gold standard for sleep monitoring and diagnosis, yet it is difficult to use in home environments. This study evaluated the performance of a wearable electroencephalographic (EEG) device, LANMAO Sleep Recorder in EEG recording and sleep staging algorithm by comparing with PSG."
- **原文位置**：Page 2, ABSTRACT - Background

### 片段2：研究方法
> "Sleep of 7 Chinese adults were recorded concurrently with PSG and LANMAO devices. First, we validated the consistency of the raw signals with relative spectral power and Pearson correlation coefficient. Second, we evaluated the performance of the automated sleep staging algorithm integrated in the LANMAO device by comparing with the staging by experts."
- **原文位置**：Page 2, ABSTRACT - Method

### 片段3：核心结果
> "The Pearson correlation coefficient between the relative spectral power of multiple frequency bands during the sleep stages ranged from 0.7613 to 0.8816, with the strongest correlation observed for delta waves (r=0.8816)."
> "The overall F1-Score of the automated sleep staging algorithm was 84.03%, with individual F1-Scores for each class as follows: Wake: 93.67%, REM: 87.23%, Light Sleep: 72.10%, and Deep Sleep: 82.82%."
- **原文位置**：Page 2, ABSTRACT - Results

### 片段4：研究结论
> "The results suggest that the EEG recorded by the LANMAO Sleep Recorder is precise and valid, and its automated sleep staging algorithm can accurately perform sleep staging with high accuracy."
- **原文位置**：Page 2, ABSTRACT - Conclusion

### 片段5：技术细节
> "LM records the frontal single-channel EEG data during sleep and the sleep staging algorithm is based on the LightGBM framework, which exhibits high accuracy and computational speed."
- **原文位置**：Page 3, INTRODUCTION

## 适用范围

- **地区**：中国大陆（上海）
- **对象**：7名中国成人受试者（具体年龄、性别未详）
- **时间**：2023年5月（论文发布日期）
- **监测信号类型**：
  - 单通道额叶EEG（FP1-FP2）
  - 头部运动信息（用于睡眠分期）
- **与PSG对比的精度指标**：
  - 信号一致性：Pearson r = 0.7613-0.8816（delta波最强）
  - 睡眠分期总体F1-Score：84.03%
  - 各类F1-Score：Wake 93.67%, REM 87.23%, Light Sleep 72.10%, Deep Sleep 82.82%

## 局限

### ⚠️ 重要局限

1. **预印本，未经同行评审**：
   - 该论文为medRxiv预印本，**未经同行评审**
   - 研究质量和结论可靠性未经独立验证
   - 不应作为临床实践的指导依据

2. **厂商作者主导，存在利益冲突**：
   - **第一单位**：Shanghai Quanlan Technology Co., Ltd（上海全澜科技有限公司）
   - **通讯作者**：Jian Jiang，上海全澜科技有限公司
   - **第二单位**：Shanghai Mental Health Center（上海市精神卫生中心）
   - **关键问题**：研究由产品公司作者主导，属于**厂商自研验证**而非独立第三方验证
   - **利益冲突**：作者可能从产品商业化中获益，研究结果可能存在偏倚

3. **样本量较小**：
   - 仅7名受试者，样本量较小
   - 结果可能不稳定，需要更大样本验证

4. **研究设计局限**：
   - 仅对比单通道EEG与PSG的FP1-FP2通道
   - 未说明受试者的年龄、性别、睡眠状况等详细信息
   - 未说明是否有睡眠障碍患者参与

5. **算法透明度不足**：
   - 仅提及使用LightGBM框架
   - 未详细说明模型训练数据、特征工程、超参数设置等

6. **长期效果未知**：
   - 仅评估单次使用的准确性
   - 未评估长期使用的一致性和可靠性

## 备注

该论文为LANMAO Sleep Recorder（澜猫睡眠X8）与PSG金标准对比的验证研究，**但为厂商自研验证，未经独立第三方验证**。

**与SRC001的关系**：SRC001产品手册第7页引用该论文作为验证证据

**正确引用方式**：
> "澜猫睡眠X8产品手册引用了一项与PSG对比的验证研究（SRC007），报告显示总体F1-Score为84.03%，delta波相关性最强（r=0.8816）。但需注意，该研究为厂商（上海全澜科技）作者主导的预印本，未经同行评审，样本量仅7人，存在利益冲突，需独立第三方验证。"

---
*创建时间：2026-10-09 | 来源卡状态：✅ 已提取全文*