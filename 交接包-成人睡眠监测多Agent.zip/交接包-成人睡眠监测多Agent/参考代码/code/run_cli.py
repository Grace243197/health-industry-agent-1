# -*- coding: utf-8 -*-
"""
============================================================
 命令行入口  run_cli.py
============================================================

这是 Agent 的"人机对话"形态：你在终端里打字，它回答你。

【四种运行方式】

    python run_cli.py --check        自检。不调用模型、不花钱，先确认各零件就位
    python run_cli.py --demo         跑一段预设剧本，完整展示 Agent 的工作过程
    python run_cli.py "你的问题"      执行单个任务
    python run_cli.py                进入交互模式，可以连续对话

【交互模式里的命令】

    /tools    查看能力清单        /memory  查看长期记忆
    /trace    查看上次执行轨迹    /reset   清空当前会话
    /forget   清空长期记忆        /config  查看当前配置
    /help     帮助               /quit    退出
"""

from __future__ import annotations

import json
import os
import sys

from agent import Agent

# ------------------------------------------------------------ 终端着色
# 判断终端是否支持颜色。重定向到文件时自动关闭，避免日志里出现乱码。
_COLOR_ENABLED = hasattr(sys.stdout, "isatty") and sys.stdout.isatty()


def color(code, text):
    if not _COLOR_ENABLED:
        return text
    return "\033[{0}m{1}\033[0m".format(code, text)


def title(text, subtitle=""):
    line = "=" * 70
    print("\n" + color("1;36", line))
    print(color("1;36", "  " + text))
    if subtitle:
        print(color("36", "  " + subtitle))
    print(color("1;36", line))


def label(name, text, code="37"):
    print(color("1;" + code, "[{0}] ".format(name)) + text)


def user_said(text):
    print(color("1;33", "[你] ") + text)


def agent_said(text):
    print(color("1;32", "[小橙] ") + text)


def hint(text):
    print(color("90", "   " + text))


def alert(text):
    print(color("1;31", "[!] " + text))


def pad(text, width):
    """按显示宽度对齐。中文占 2 格、英文占 1 格，直接用 format 对不齐。"""
    text = str(text)
    shown = sum(2 if ord(ch) > 0x2E80 else 1 for ch in text)
    return text + " " * max(width - shown, 0)


# ------------------------------------------------------------ 演示剧本
# 这是一个具体的虚构场景：新员工「小林」入职青橙科技第一周遇到的事务问题。
# 四个任务分别考察 Agent 的四种核心能力。
DEMO_SCRIPT = [
    {
        "title": "任务一：查知识库（考察 RAG 检索与引用）",
        "task": "我是新来的，办公 WiFi 叫什么名字？入职培训是什么时候、在哪里？",
        "check": lambda answer: "QC-Office" in answer and "周三" in answer,
        "explain": "这两个信息只存在于公司内部文档里，模型不可能凭记忆知道。\n"
                   "            它必须先调用 search_knowledge 查到原文，才能答对并标注出处。",
    },
    {
        "title": "任务二：记忆 + 知识库联动（考察把散落信息串起来）",
        "task": "我叫小林，职级 P5，在市场部。请帮我记住。",
        "check": lambda answer: True,
        "explain": "它应该调用 save_memory 把这三条信息存进长期记忆文件，\n"
                   "            关掉程序明天再来，它依然记得你是小林。",
    },
    {
        "title": "任务三：多工具串联 + 自主规划（考察 Agent 的核心价值）",
        "task": "我下周要去上海出差 3 天 2 晚。按我的职级标准，"
                "帮我算一下住宿和餐补的报销上限合计是多少，"
                "并把明细整理成一份文件保存为 travel_budget.txt。",
        "check": lambda answer: ("1220" in answer or "1,220" in answer
                                 or "1310" in answer or "1,310" in answer),
        "explain": "这一题需要它自己规划出四步：\n"
                   "            ① 从长期记忆里想起「小林是 P5」\n"
                   "            ② 查知识库拿到「P4-P6 一线城市住宿 520 元/晚」「餐补 90 元/天，首末日半天 45 元」\n"
                   "            ③ 用计算器算：住宿 520×2=1040，餐补 45+90+45=180，合计 1220 元\n"
                   "            ④ 调用 save_file 把明细写进 travel_budget.txt\n"
                   "            我们从没告诉它这个顺序 —— 这就是 Agent 和普通脚本的区别。\n"
                   "            若它答 1310，说明漏了「首末日按半天算」这条规则，属于检索到了但没读细。",
    },
    {
        "title": "任务四：拒答能力（最重要的一测）",
        "task": "公司健身房的开放时间是几点到几点？私教课怎么预约？",
        "check": lambda answer: any(w in answer for w in
                                   ("未找到", "没有找到", "没有相关", "未查询到", "无相关")),
        "explain": "知识库里**根本没有**任何关于健身房的内容。\n"
                   "            它必须承认「未找到相关信息」，而不是编一个开放时间。\n"
                   "            这一条比前面全部答对更重要 —— 敢拒答的 Agent 才敢上生产环境。",
    },
]


def run_demo():
    """跑完整演示剧本。给甲方演示、给新人讲解时，用这个就够了。"""
    title("青橙科技「小橙」员工服务助手 · 演示剧本",
          "场景：新员工小林入职第一周，向助手咨询各类事务")

    assistant = Agent()
    print(assistant.describe())
    if assistant.knowledge_warning:
        alert(assistant.knowledge_warning)

    session = assistant.new_session()      # 四个任务共用一个会话，才能体现"记忆"
    total_tokens = 0
    passed = 0

    for index, item in enumerate(DEMO_SCRIPT, 1):
        print("\n" + "=" * 70)
        label(item["title"], "", "33")
        hint("考察点：" + item["explain"].split("\n")[0].strip())
        print("-" * 70)
        user_said(item["task"])

        result = assistant.run(item["task"], session=session, verbose=True)
        total_tokens += result.total_tokens

        print()
        ok = bool(item["check"](result.answer))
        passed += 1 if ok else 0
        if ok:
            hint("✓ 符合预期")
        else:
            alert("✗ 与预期不符（模型输出有随机性，可再跑一次；持续失败请检查知识库与提示词）")

        print()
        for key, value in result.summary():
            hint("  {0}: {1}".format(pad(key, 14), value))

    print("\n" + "=" * 70)
    label("演示结束", "共 {0} 个任务，{1} 个符合预期，消耗 {2} token".format(
        len(DEMO_SCRIPT), passed, total_tokens), "32")
    hint("完整执行轨迹已保存在 traces/ 目录，可以逐条复盘它每一步做了什么。")
    hint("当前长期记忆内容：")
    for line in (assistant.memory.all_text() if assistant.memory else "(未启用)").splitlines():
        hint("  " + line)


# ------------------------------------------------------------ 自检
def run_check():
    """交付前的第一件事：确认所有零件就位、安全边界有效。不消耗任何 API 额度。"""
    title("Agent 自检", "不调用模型，不消耗额度")
    assistant = Agent()
    print(assistant.describe())
    if assistant.knowledge_warning:
        alert(assistant.knowledge_warning)

    print("\n--- 一、能力清单（这就是交付文档里的「Agent 能做什么」）---")
    for row in assistant.tool_manifest():
        print("  • {0}({1})".format(row["name"], row["parameters"]))
        print("      " + row["description"][:100])

    print("\n--- 二、检索质量抽检（纯本地，不调模型）---")
    probes = ["住宿报销标准", "年假天数", "WiFi 密码", "设备报修", "批量采购折扣"]
    if assistant.knowledge:
        for probe in probes:
            hits = assistant.knowledge.search(probe, top_k=1)
            if hits:
                chunk, score = hits[0]
                hint("  「{0}」 → [{1:.2f}] {2} > {3}".format(
                    probe, score, chunk["doc"], chunk["heading"].split(" > ")[-1]))
            else:
                alert("  「{0}」 → 无命中，请检查知识库内容".format(probe))

    print("\n--- 三、安全边界抽检 ---")
    attacks = [
        ("read_file", {"path": "../../.env"}, "读取上级目录的密钥文件"),
        ("read_file", {"path": "C:/Windows/win.ini"}, "读取系统文件"),
        ("read_file", {"path": "../../../.ssh/id_rsa"}, "读取 SSH 私钥"),
    ]
    for tool_name, arguments, description in attacks:
        output = assistant.tools.call(tool_name, json.dumps(arguments))
        blocked = output.startswith(("权限拒绝", "错误"))
        hint("  {0} → {1}".format(description, "已拦截" if blocked else "!!! 未拦截 !!!"))

    injection = assistant.tools.call(
        "calculator", json.dumps({"expression": "__import__('os').system('dir')"}))
    hint("  计算器代码注入 → {0}".format(
        "已拦截" if injection.startswith("错误") else "!!! 未拦截 !!!"))

    print("\n--- 四、基本运算抽检 ---")
    hint("  5299 * 0.96 * 10 = " + assistant.tools.call(
        "calculator", json.dumps({"expression": "5299 * 0.96 * 10"})))
    hint("  当前时间 = " + assistant.tools.call("get_time", "{}"))

    print("\n自检完成。" + ("" if assistant.config.online else
                        "（当前未配置 API 密钥，将使用试用模式）"))


# ------------------------------------------------------------ 单次任务
def run_once(task):
    assistant = Agent()
    label("配置", "\n" + assistant.config.describe())
    result = assistant.run(task, verbose=True)
    print()
    for key, value in result.summary():
        hint("  {0}: {1}".format(pad(key, 14), value))
    return 0 if result.ok else 1


# ------------------------------------------------------------ 交互模式
HELP_TEXT = """可用命令：
    /tools    查看 Agent 的能力清单
    /memory   查看长期记忆里存了什么
    /trace    查看上一次任务的执行轨迹
    /reset    清空当前会话（短期记忆），重新开始
    /forget   清空长期记忆
    /config   查看当前配置
    /help     显示本帮助
    /quit     退出"""


def run_chat():
    title("青橙科技「小橙」员工服务助手", "输入问题开始对话，输入 /help 看命令，/quit 退出")
    assistant = Agent()
    label("配置", "\n" + assistant.config.describe())
    if assistant.knowledge_warning:
        alert(assistant.knowledge_warning)
    label("试试问我", "报销标准、年假天数、WiFi 密码、设备报修流程，"
                  "或者让我帮你算一笔账、写一份清单")

    session = assistant.new_session()
    last_result = None

    while True:
        print()
        try:
            text = input(color("1;36", "你 > ") if _COLOR_ENABLED else "你 > ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n再见。")
            break

        if not text:
            continue

        command = text.lower()
        if command in ("/quit", "/exit", "quit", "exit"):
            print("再见。")
            break
        if command == "/help":
            print(HELP_TEXT)
            continue
        if command == "/config":
            print(assistant.config.describe())
            continue
        if command == "/tools":
            for row in assistant.tool_manifest():
                print("  • {0}({1})\n      {2}".format(
                    row["name"], row["parameters"], row["description"][:100]))
            continue
        if command == "/memory":
            print(assistant.memory.all_text() if assistant.memory else "(未启用长期记忆)")
            continue
        if command == "/reset":
            session = assistant.new_session()
            hint("已清空当前会话。")
            continue
        if command == "/forget":
            if assistant.memory:
                assistant.memory.reset()
            hint("已清空长期记忆。")
            continue
        if command == "/trace":
            if last_result and last_result.trace_path and os.path.isfile(last_result.trace_path):
                with open(last_result.trace_path, "r", encoding="utf-8") as file:
                    data = json.load(file)
                for call in data["result"]["tool_calls"]:
                    print("    第 {0} 步  {1}({2})".format(
                        call["step"], call["name"], call["arguments"][:70]))
                hint("完整轨迹文件：" + last_result.trace_path)
            else:
                hint("(还没有执行过任务)")
            continue

        last_result = assistant.run(text, session=session, verbose=True)


# ------------------------------------------------------------ 入口
def main():
    # Windows 终端默认可能不是 UTF-8，中文会显示成乱码，这里统一切换一下
    if sys.platform == "win32":
        for stream in (sys.stdin, sys.stdout, sys.stderr):
            try:
                stream.reconfigure(encoding="utf-8", errors="replace")
            except Exception:                                       # noqa: BLE001
                pass

    arguments = [a for a in sys.argv[1:] if a.strip()]

    if not arguments:
        run_chat()
    elif arguments[0] in ("--check", "-c", "check"):
        run_check()
    elif arguments[0] in ("--demo", "-d", "demo"):
        run_demo()
    elif arguments[0] in ("--help", "-h"):
        print(__doc__)
    else:
        run_once(" ".join(arguments))


if __name__ == "__main__":
    main()
