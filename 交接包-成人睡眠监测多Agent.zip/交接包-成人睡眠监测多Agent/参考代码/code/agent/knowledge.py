# -*- coding: utf-8 -*-
"""
============================================================
 第 3 部分：知识库  knowledge.py
============================================================

【这一部分负责什么】

让 Agent 能查到"它本来不可能知道的事"—— 你公司的制度、产品参数、内部流程。

【为什么需要它】

大模型的知识来自公开互联网的训练数据，它**不可能**知道：
    - 你们公司 P5 出差住宿能报多少钱
    - 你们产品的内部结算价
    - 你们几点上班

如果你直接问，它只有两种反应：说"我不知道"（没用），或者**编一个像模像样的数字**（危险）。
后者有个专业名词叫「幻觉 Hallucination」。

【解决办法：RAG】

RAG = Retrieval-Augmented Generation，检索增强生成。名字唬人，流程特别朴素：

    ┌────────┐   ┌────────┐   ┌────────┐   ┌────────┐
    │ ① 切块  │ → │ ② 变数字 │ → │ ③ 查相似 │ → │ ④ 塞提示 │
    └────────┘   └────────┘   └────────┘   └────────┘
     把长文档      把文字转成     找出跟问题     把找到的原文
     切成小段      一串数字       最相关的几段   和问题一起发给模型

打个比方：
    不用 RAG 的模型 = 闭卷考试的学生，记不清就瞎编
    用了 RAG 的模型 = 开卷考试的学生，先翻书找到那一页，再照着答

【RAG 相比"重新训练模型"的好处】
    改文档 = 改知识。秒级生效、零成本、可随时回滚。
    而重新训练（微调）一次要几小时到几天，还要花钱，改一个字都得重来。

【本文件的实现选择】

工业界常用「向量模型 + 向量数据库」。但那样你就看不见原理了，还要多装三个库。
所以这里用**纯 Python 手写的 TF-IDF**，零依赖，不到 100 行，原理一目了然。
接口和向量库完全一致（都是 search(问题) → [(片段, 分数)]），
将来知识库变大要升级，只换这个文件的内部实现即可，Agent 其他部分一行不用改。

【中文分词的取巧办法】
中文没有空格，正规做法要用分词器（如 jieba）。这里改用「字级二元组」：
    "报销标准"  →  ["报销", "销标", "标准"]
好处：零依赖，而且对专有名词友好（不会因为分词器不认识"青橙"而切错）。
"""

from __future__ import annotations

import math
import os
import re
from collections import Counter

# 匹配连续的英文字母和数字，例如 "Book"、"14"、"2880"
_ENGLISH_TOKEN = re.compile(r"[a-zA-Z0-9]+(?:\.[0-9]+)?")
# 匹配 Markdown 标题行，例如 "## 一、住宿标准"
_MARKDOWN_HEADING = re.compile(r"^(#{1,6})\s+(.*)")
# 支持的知识库文件格式
_SUPPORTED_EXTENSIONS = (".md", ".markdown", ".txt")


def tokenize(text):
    """
    把一段文字切成"词"的列表。这是②变数字的第一步。

    中英混排分别处理：
        英文和数字 → 按整个单词保留，并统一小写
                     （这样 "Book" 和 "book" 被当成同一个词，"5299" 不会被拆成 5、2、9、9）
        中文       → 切成相邻两个字的组合

    Args:
        text: 任意文字

    Returns:
        词的列表，例如 tokenize("青橙Book 14") → ["book", "14", "青橙"]
    """
    text = (text or "").lower()

    # 英文与数字：整体保留
    tokens = [match.group() for match in _ENGLISH_TOKEN.finditer(text)]

    # 中文：只留下汉字，然后两两相邻组合
    chinese_chars = [ch for ch in text if "\u4e00" <= ch <= "\u9fff"]
    if len(chinese_chars) == 1:
        tokens.append(chinese_chars[0])
    for i in range(len(chinese_chars) - 1):
        tokens.append(chinese_chars[i] + chinese_chars[i + 1])

    return tokens


class TfidfIndex(object):
    """
    一个迷你检索引擎。核心思想叫 TF-IDF，直觉非常好懂：

        一个词，如果
            在这段话里出现得**多**（TF 高）
            在其他段落里出现得**少**（IDF 高）
        那它就最能代表这段话。

    举例："的""是""公司"这种到处都有的词，IDF 很低，自动被压得没什么权重；
         而"税号""陪产假"这种只在一两处出现的词，权重很高，一搜就中。

    建一次索引（毫秒级），之后每次查询都很快。
    """

    def __init__(self, chunks):
        """
        Args:
            chunks: 文档片段列表，每个片段是一个字典，至少要有 "heading" 和 "text"
        """
        self.chunks = list(chunks)
        # 提前把每个片段切成词，避免每次查询重复计算
        self._chunk_tokens = [tokenize(c.get("heading", "") + " " + c.get("text", ""))
                              for c in self.chunks]

        # 统计每个词出现在多少个片段里（df = document frequency 文档频率）
        document_frequency = Counter()
        for tokens in self._chunk_tokens:
            document_frequency.update(set(tokens))     # set 去重：一个片段里出现多次只算一次

        total = max(len(self.chunks), 1)
        # 计算每个词的 IDF 权重。公式里的 +1 是为了避免出现除以 0 或 log(0)。
        self.idf = {
            word: math.log((total + 1.0) / (count + 1.0)) + 1.0
            for word, count in document_frequency.items()
        }
        # 预先算好每个片段的向量，查询时只需做点积
        self._vectors = [self._to_vector(tokens) for tokens in self._chunk_tokens]

    def _to_vector(self, tokens):
        """
        把一串词变成一个"向量"（这里用字典表示：词 → 权重）。

        两步：
          1. 权重 = 词频(TF) × 稀有度(IDF)
          2. 归一化：把向量长度缩放到 1
             这样两个向量的点积就正好等于「余弦相似度」，省掉查询时的除法。

        余弦相似度是什么？
          把每段文字想象成空间里的一支箭头，比较两支箭头**方向**有多接近。
          方向越接近 = 用词越相似 = 内容越相关。结果在 0~1 之间，越大越相关。
        """
        counts = Counter(tokens)
        total = sum(counts.values()) or 1
        vector = {word: (count / float(total)) * self.idf.get(word, 1.0)
                  for word, count in counts.items()}
        length = math.sqrt(sum(v * v for v in vector.values())) or 1.0
        return {word: v / length for word, v in vector.items()}

    def search(self, query, top_k=3):
        """
        ③查相似：找出跟问题最相关的几个片段。

        Args:
            query: 用户的问题或关键词
            top_k: 返回前几名

        Returns:
            [(片段字典, 相关度分数), ...]，按分数从高到低排列。
            一个都没匹配上时返回空列表 —— 这一点很重要，
            宁可返回空让 Agent 说"没找到"，也不要硬凑几个不相关的片段骗它。
        """
        query_vector = self._to_vector(tokenize(query))
        scored = []
        for chunk, chunk_vector in zip(self.chunks, self._vectors):
            # 只遍历"问题里出现的词"，比遍历整个词表快得多
            score = sum(weight * chunk_vector[word]
                        for word, weight in query_vector.items()
                        if word in chunk_vector)
            if score > 0:
                scored.append((score, chunk))
        scored.sort(key=lambda pair: pair[0], reverse=True)
        return [(chunk, score) for score, chunk in scored[:top_k]]

    @property
    def vocab_size(self):
        """词表大小，用来看知识库的规模。"""
        return len(self.idf)


class KnowledgeBase(object):
    """
    把一个文件夹里的文档，变成 Agent 可以查询的知识库。

    用法：
        kb = KnowledgeBase("./knowledge_base")     # 自动扫描并建索引
        hits = kb.search("住宿报销标准", top_k=3)    # 查询
        print(kb.format_hits(hits))                # 转成给模型看的文字
    """

    def __init__(self, kb_dir, chunk_size=320, min_chunk_chars=20):
        """
        Args:
            kb_dir: 知识库文件夹路径
            chunk_size: 每个片段大约多少字。太小则上下文不完整，太大则检索不精准。
                        300 字左右是中文文档比较平衡的取值。
            min_chunk_chars: 少于此字数的片段直接丢弃（通常是孤零零的标题，没有信息量）
        """
        self.kb_dir = kb_dir
        self.chunk_size = chunk_size
        self.min_chunk_chars = min_chunk_chars
        self.chunks = []
        self.index = None
        self.reload()

    # ------------------------------------------------------------ 建索引
    def reload(self):
        """
        重新扫描文件夹并建立索引。

        ★ 这就是 RAG 最大的好处：知识库更新了，调用一下 reload() 就生效，
          不需要重新训练任何模型，不花一分钱，出问题还能改回去。
        """
        self.chunks = self._load_chunks() if os.path.isdir(self.kb_dir) else []
        self.index = TfidfIndex(self.chunks)
        return self

    def _load_chunks(self):
        """
        ①切块：把文档切成小段。

        【为什么必须切块】
            1. 模型一次能读的字数有限（上下文窗口），塞不下整本手册
            2. 无关内容太多会"稀释"注意力，模型反而更容易答错
            3. 检索的粒度越细，塞给模型的原文就越精准

        【切块的讲究】
            按语义边界切，而不是每 300 字硬切一刀。
            这里以 Markdown 标题（# ## ###）为边界，并且把标题路径一起存下来。
            为什么？因为单独一句"上限 520 元"毫无意义，
            配上"差旅报销制度 > 住宿标准 > P4-P6 > 一线城市"才可用，也才能做引用标注。
        """
        chunks = []
        for filename in sorted(os.listdir(self.kb_dir)):
            if not filename.lower().endswith(_SUPPORTED_EXTENSIONS):
                continue
            path = os.path.join(self.kb_dir, filename)
            try:
                with open(path, "r", encoding="utf-8") as file:
                    lines = file.read().splitlines()
            except (OSError, UnicodeDecodeError):
                # 某个文件读不了（编码坏了、被占用），跳过它，
                # 不能让一个坏文件导致整个知识库建不起来。
                continue

            heading_path = []      # 当前的标题层级，例如 ["差旅制度", "住宿标准"]
            buffer = []            # 正在累积的片段内容
            buffer_length = 0

            def flush():
                """把当前累积的内容存成一个片段。"""
                if not buffer:
                    return
                text = "\n".join(buffer).strip()
                del buffer[:]                        # 清空，准备装下一段
                if len(text) < self.min_chunk_chars:
                    return                           # 太短，没有信息量，丢弃
                chunks.append({
                    "doc": filename,
                    "heading": " > ".join(heading_path) or "(文档开头)",
                    "text": text,
                })

            for line in lines:
                heading_match = _MARKDOWN_HEADING.match(line)
                if heading_match:
                    # 遇到新标题：先把上一段存起来，再更新标题层级
                    flush()
                    level = len(heading_match.group(1))      # "###" → 3
                    title = heading_match.group(2).strip()
                    del heading_path[level - 1:]             # 去掉同级和更深的旧标题
                    heading_path.append(title)
                    buffer.append(line)
                    buffer_length = 0
                    continue

                buffer.append(line)
                buffer_length += len(line)
                # 内容够长了，就在空行处切一刀（空行处切不会把一句话劈成两半）
                if buffer_length >= self.chunk_size and not line.strip():
                    flush()
                    buffer_length = 0

            flush()      # 文件结束，别忘了最后一段
        return chunks

    # ------------------------------------------------------------ 查询
    def search(self, query, top_k=3):
        """查询知识库，返回 [(片段, 分数), ...]。"""
        if not self.index or not self.chunks:
            return []
        return self.index.search(query, top_k=top_k)

    def format_hits(self, hits):
        """
        ④塞提示：把检索结果拼成一段给模型看的文字。

        为什么要编号、要带出处？
          - 编号让模型能明确说"根据资料 2"
          - 出处让它能在回答末尾标注 [来源: xxx]，用户可以去核对
          - 相关度分数便于你排查"为什么它答错了" —— 通常是检索没捞到对的片段

        一个片段都没检索到时，返回一句明确的指令，要求模型如实说"没找到"。
        这一句非常关键：它是防止幻觉的最后一道闸门。
        """
        if not hits:
            return ("（知识库中没有检索到相关内容。"
                    "请如实告知用户「未找到相关规定」，并说明缺少哪方面的资料，"
                    "严禁编造任何数字或结论。）")

        parts = []
        for i, (chunk, score) in enumerate(hits, 1):
            parts.append(
                "--- 资料 {0}（相关度 {1:.3f}）---\n"
                "出处：{2} > {3}\n"
                "{4}".format(i, score, chunk["doc"], chunk["heading"], chunk["text"])
            )
        return "\n\n".join(parts)

    def stats(self):
        """知识库的规模统计，用于自检报告和交付文档。"""
        return {
            "kb_dir": self.kb_dir,
            "documents": len(set(c["doc"] for c in self.chunks)),
            "chunks": len(self.chunks),
            "vocab_size": self.index.vocab_size if self.index else 0,
        }
