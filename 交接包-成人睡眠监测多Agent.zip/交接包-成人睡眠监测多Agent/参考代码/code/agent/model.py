# -*- coding: utf-8 -*-
"""
============================================================
 第 2 部分：大脑  model.py
============================================================

【这一部分负责什么】

跟大模型说话。整个项目里，**只有这一个文件**会联网访问 AI 服务。

【为什么要单独抽出来】

因为"大脑"是最容易被换掉的零件。今天用 A 家的模型，明年可能换成 B 家，
或者公司要求换成内网私有部署的模型。
把网络请求全部关在这一个文件里，换大脑时就只改这里，其他代码一行不用动。

【一个关键认知】

调用大模型，本质上就是**发一个 HTTP 请求**：

    发过去：{"model": "模型名", "messages": [对话历史], "tools": [工具清单]}
    收回来：{"choices": [{"message": {"content": "回答", "tool_calls": [...]}}]}

没有魔法，没有框架，一个 requests 库就够了。

【对话历史 messages 的四种角色】

    system     你给 Agent 定的规则和人设（"你是青橙科技的员工服务助手……"）
    user       用户说的话
    assistant  模型说的话，或者模型"想调用某个工具"的声明
    tool       工具执行完的结果，回传给模型看

模型是**无状态**的：它不记得上一次请求。
所以每次都要把完整历史重新发一遍 —— 这也是"记忆"要靠工程实现的原因。
"""

from __future__ import annotations

import json
import time

import requests


class ModelError(Exception):
    """模型调用失败时抛出。上层可以捕获它，给用户一个友好的提示而不是让程序崩掉。"""


class Model(object):
    """大模型客户端。负责发请求、重试、统计用量。"""

    def __init__(self, config, offline=False):
        """
        Args:
            config: Config 对象，从里面取 api_key / base_url / model 等参数
            offline: 强制使用离线假模型。跑评测框架自检、写自动化测试时用，
                     这样既不用联网也不会花钱。
        """
        self.config = config
        self.offline = offline
        # 统计信息，用来算成本和写报告
        self.request_count = 0
        self.total_tokens = 0

    # ------------------------------------------------------------ 对外主接口
    def chat(self, messages, tools=None):
        """
        发一轮对话，返回 (模型回复的消息, 本次用量)。

        Args:
            messages: 完整对话历史，一个字典列表，从旧到新排列
            tools:    工具清单（JSON 格式）。传了它，模型才有"点工具"的能力；
                      不传，模型就只能纯聊天。

        返回的"消息"里有两个关键字段：
            content     模型说的话（可能为空字符串）
            tool_calls  模型想调用的工具列表（可能不存在）

        ★ 理解 Agent 的关键：
          模型返回 tool_calls 时，它**并没有真的执行**任何工具。
          它只是说了一句"我想调用 get_time"，真正去执行的是我们自己的代码。
        """
        # 强制离线，或没配密钥 → 走离线假模型，让整个流程依然能跑通
        if self.offline or not self.config.online:
            return offline_model(messages, tools)

        # ---------- 组装请求体 ----------
        payload = {
            "model": self.config.model,
            "messages": messages,
            "temperature": self.config.temperature,
            "max_tokens": self.config.max_tokens,
        }
        if tools:
            payload["tools"] = tools
            # tool_choice="auto" 表示：由模型自己决定这一轮要不要用工具
            payload["tool_choice"] = "auto"

        # 「深度思考」开关。只有你在 .env 里明确设置了才会发送 ——
        # 因为它不是通用标准字段，贸然发给不认识它的服务商会报错。
        if self.config.enable_thinking is not None:
            payload["enable_thinking"] = self.config.enable_thinking

        # ---------- 发请求（带重试） ----------
        data = self._post_with_retry(payload)

        choices = data.get("choices") or []
        if not choices:
            raise ModelError("接口没有返回任何内容：" +
                             json.dumps(data, ensure_ascii=False)[:300])

        message = choices[0].get("message") or {}
        # 只保留协议规定的字段。有些服务商会在回复里多塞一些自定义字段，
        # 原样回传可能导致下一轮请求被拒绝，所以这里做一次清洗。
        message = {k: v for k, v in message.items()
                   if k in ("role", "content", "tool_calls", "name")}
        if not message.get("role"):
            message["role"] = "assistant"

        # ---------- 记账 ----------
        usage = data.get("usage") or {}
        self.request_count += 1
        self.total_tokens += usage.get("total_tokens", 0)
        return message, usage

    # ------------------------------------------------------------ 内部：带重试的请求
    def _post_with_retry(self, payload):
        """
        发送 HTTP 请求，失败时按"指数退避"重试。

        为什么要重试？
            网络会抖动，服务会限流，这些都不是你的代码有 bug，等一下再试往往就好了。

        为什么是"指数退避"（等 1 秒、2 秒、4 秒）而不是立刻疯狂重试？
            服务限流时，你重试得越猛，它越堵，最后谁都拿不到结果。
            逐渐拉长间隔，是给服务喘息的时间。

        哪些错误值得重试？
            429（请求太频繁）和 5xx（服务器故障）→ 值得，这不是你的问题
            4xx（比如 401 密钥错、400 参数错）  → 不值得，重试一百次也是同样的错
        """
        url = self.config.base_url.rstrip("/") + "/chat/completions"
        headers = {
            "Authorization": "Bearer " + self.config.api_key,
            "Content-Type": "application/json",
        }

        last_error = "未知错误"
        for attempt in range(self.config.max_retries + 1):
            try:
                response = requests.post(url, headers=headers, json=payload,
                                         timeout=self.config.timeout)
            except requests.RequestException as exc:
                last_error = "网络异常 {0}: {1}".format(type(exc).__name__, exc)
            else:
                if response.status_code == 200:
                    return response.json()
                detail = "HTTP {0}: {1}".format(response.status_code, response.text[:200])
                if response.status_code == 429 or response.status_code >= 500:
                    last_error = detail          # 可重试
                else:
                    raise ModelError(detail)     # 不可重试，立刻抛出让用户去检查配置

            if attempt < self.config.max_retries:
                time.sleep(2 ** attempt)         # 1 秒、2 秒、4 秒……

        raise ModelError("重试 {0} 次后仍然失败 —— {1}".format(
            self.config.max_retries, last_error))


# ============================================================
# 试用模式：一个离线假模型
# ============================================================
def offline_model(messages, tools=None):
    """
    没有 API 密钥时顶替真实模型。

    【它存在的意义】
    1. 你还没申请到密钥，也能先把界面、流程、工具全部跑通看看
    2. 写自动化测试时不能依赖真实模型 —— 真模型每次回答都不一样，测试没法判定对错
    3. 它证明了一件事：**Agent 的价值在"编排"，模型只是可替换的一个零件**

    【它是怎么工作的】
    完全不是神经网络，就是一堆 if-else 关键词规则：
    看到"报销""年假"就假装去查知识库，看到"几点"就假装查时间，
    已经拿到工具结果了就编一段总结。

    返回格式和真实模型**完全一致**，所以上层代码分不清也不需要分清。
    """
    import re

    usage = {"prompt_tokens": 60, "completion_tokens": 20, "total_tokens": 80}
    available = {t["function"]["name"] for t in (tools or [])}

    # 找出用户最后说的那句话
    last_user = ""
    for item in reversed(messages):
        if item.get("role") == "user":
            last_user = item.get("content") or ""
            break

    # 如果上一轮已经执行过工具了，就把工具结果整理成一段回答
    tool_results = [m for m in messages if m.get("role") == "tool"]
    if tool_results:
        evidence = "\n".join(str(t.get("content"))[:260] for t in tool_results[-2:])
        answer = ("【试用模式】根据刚才工具返回的内容，整理如下：\n\n{0}\n\n"
                  "（当前未配置 API 密钥，以上是把工具结果直接拼接出来的。"
                  "在 .env 里填入 AGENT_API_KEY 后，就能得到真实的智能回答。）").format(
                      evidence.strip() or "（工具没有返回内容）")
        return {"role": "assistant", "content": answer}, usage

    # 关键词 → 工具 的映射表
    rules = [
        (r"报销|住宿|餐补|差旅|发票|税号|打车|交通", "search_knowledge"),
        (r"年假|假期|考勤|打卡|加班|调休|产假|婚假|病假|上班时间", "search_knowledge"),
        (r"入职|WiFi|wifi|网络|账号|邮箱|VPN|门禁|培训|工位", "search_knowledge"),
        (r"电脑|笔记本|设备|显示器|Book|保修|维修|报修|丢失", "search_knowledge"),
        (r"会议室|快递|加班餐|采购|折扣|客服热线|在家办公", "search_knowledge"),
        (r"几点|现在时间|今天几号|星期几", "get_time"),
        (r"算|计算|合计|多少钱|总共", "calculator"),
        (r"有哪些文件|列一下目录", "list_dir"),
        (r"我叫|我是|记住|我的职级", "save_memory"),
        (r"我是谁|我叫什么|记得我", "recall_memory"),
    ]

    round_index = len([m for m in messages if m.get("role") == "assistant"]) + 1
    for pattern, tool_name in rules:
        if tool_name in available and re.search(pattern, last_user):
            arguments = _guess_arguments(tool_name, last_user)
            call = {
                "id": "offline_{0}".format(round_index),
                "type": "function",
                "function": {"name": tool_name,
                             "arguments": json.dumps(arguments, ensure_ascii=False)},
            }
            return {"role": "assistant", "content": "", "tool_calls": [call]}, usage

    return {"role": "assistant", "content":
            "【试用模式】我是青橙科技员工服务助手小橙。\n"
            "当前未配置 API 密钥，我只能按关键词规则响应，无法真正理解你的问题。\n"
            "请在 .env 中填入你的 AGENT_API_KEY 后重启，即可获得完整能力。\n\n"
            "你可以先试试问我："
            "「P5 去上海出差住宿能报多少」「年假有几天」「帮我算一下 5299 的 96 折」"}, usage


def _guess_arguments(tool_name, text):
    """给离线假模型编一套看起来合理的工具参数。"""
    import re
    cleaned = re.sub(r"[？?。！!，,、]", " ", text).strip()
    if tool_name == "search_knowledge":
        return {"query": cleaned[:28], "top_k": 3}
    if tool_name == "calculator":
        match = re.search(r"[\d\.\+\-\*/\(\)\s]{3,}", text)
        return {"expression": match.group().strip() if match else "1+1"}
    if tool_name == "save_memory":
        return {"content": cleaned[:50], "category": "用户信息"}
    if tool_name == "recall_memory":
        return {"query": "姓名 职级 部门", "top_k": 3}
    if tool_name == "list_dir":
        return {"path": "."}
    return {}
