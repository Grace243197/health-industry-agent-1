# -*- coding: utf-8 -*-
"""
============================================================
 第 4 部分：记忆  memory.py
============================================================

【这一部分负责什么】

让 Agent 记住事情。分两种：
    短期记忆 —— 本次对话里说过的话（关掉窗口就没了）
    长期记忆 —— 关于这个用户的重要事实（明天再来还记得）

【一个必须先建立的正确认知】

    ★ 大模型是「无状态」的。★
    每一次请求，对它来说都是第一次见面。它根本不记得你上一句说了什么。

那为什么聊天软件看起来"记得"整段对话？
因为**是程序每次都把完整历史重新发过去了一遍**。
所谓记忆，是工程手段做出来的，不是模型自带的能力。

【三层记忆对照表】

    ┌──────────────┬────────────────────┬─────────────────────────┐
    │ 类型         │ 存在哪              │ 解决什么问题              │
    ├──────────────┼────────────────────┼─────────────────────────┤
    │ ① 短期记忆    │ 内存里的一个列表     │ 本次对话的连贯性           │
    │ ② 长期记忆    │ 一个 JSON 文件      │ 跨会话记住"你是谁"         │
    │ ③ 外部知识    │ 知识库文件夹        │ 公司制度、产品资料（见      │
    │              │                    │ knowledge.py）           │
    └──────────────┴────────────────────┴─────────────────────────┘

    ②和③的区别：长期记忆存"这个用户的事"，知识库存"公司的事"。
    但技术实现几乎一样 —— 都是"存下来，需要时查出来，拼进提示词"。

【短期记忆的难点：聊久了怎么办】

    历史越长 → ① 越贵（每轮都为全部历史付费）② 越慢 ③ 模型越容易分心。
    所以要设一个"上下文预算"，超了就丢掉最早的消息（叫「滑动窗口」）。
"""

from __future__ import annotations

import datetime
import json
import os

from .knowledge import TfidfIndex


class ShortTermMemory(object):
    """
    短期记忆 = 一次会话的对话历史。

    本体就是一个列表，真正需要用心处理的是两件事：
        1. 历史太长时怎么裁剪
        2. 裁剪之后怎么保证消息格式仍然合法
    """

    def __init__(self, system_prompt="", budget_chars=24000):
        """
        Args:
            system_prompt: 给 Agent 定的规则（system 角色的内容）
            budget_chars: 上下文预算，单位是字符数。
                          正式项目可以换成 token 数，原理完全一样。
        """
        self.system_prompt = system_prompt
        self.budget = budget_chars
        self.turns = []          # 按时间顺序存放 user / assistant / tool 消息

    # ------------------------------------------------------------ 基本操作
    def add(self, message):
        """往历史里追加一条消息。message 是一个字典，至少包含 role 和 content。"""
        self.turns.append(message)

    def add_user(self, content):
        """追加一条用户消息（便捷方法）。"""
        self.add({"role": "user", "content": content})

    def clear(self):
        """清空历史，相当于"开启一段新对话"。"""
        self.turns = []

    def size(self):
        """当前历史占多少字符。"""
        return sum(len(str(m.get("content") or "")) for m in self.turns)

    def __len__(self):
        return len(self.turns)

    # ------------------------------------------------------------ 组装成可发送的消息
    def messages(self):
        """
        返回本次请求要发送的完整消息列表。

        做了两件事：
            1. 超出预算就丢掉最早的消息（滑动窗口）
            2. 丢掉之后修复消息配对关系（见 _repair 的说明）
        """
        head = {"role": "system", "content": self.system_prompt}
        kept = []
        dropped = 0
        total = 0

        # 从最新的往回累加，一旦超出预算，更早的消息全部丢弃
        for message in reversed(self.turns):
            length = len(str(message.get("content") or ""))
            if total + length > self.budget and kept:
                dropped += 1
                continue
            kept.append(message)
            total += length
        kept.reverse()       # 因为是从后往前收集的，要翻回正序

        if dropped:
            # ★ 重要细节：不能"悄悄地"丢。
            #   明确告诉模型"前面还有 N 条没给你看"，它缺信息时会主动向用户确认，
            #   而不是自己脑补一个答案。悄悄丢弃会让它莫名其妙地答错。
            kept.insert(0, {
                "role": "system",
                "content": ("（系统提示：为控制上下文长度，已省略更早的 {0} 条消息。"
                            "若缺少必要信息，请向用户确认，不要臆测。）").format(dropped),
            })

        return [head] + self._repair(kept)

    @staticmethod
    def _repair(kept):
        """
        修复裁剪后可能出现的"消息配对断裂"。

        【背景知识】工具调用在对话历史里是成对出现的：
            assistant 消息（带 tool_calls，意思是"我要调用某工具"）
                ↓ 必须紧跟
            tool 消息（带 tool_call_id，意思是"这是那次调用的结果"）

            接口有两条硬性要求：
              规则 1：每条 tool 消息，前面必须能找到对应的 assistant 消息
              规则 2：assistant 声明的每一个工具调用，后面都必须有对应结果，一个都不能少

            裁剪历史时如果刚好从中间切开，就会产生"落单"的消息，
            请求会被接口直接拒绝。所以裁剪完必须做一次清理。

        处理办法：
            - 删掉找不到对应 assistant 的 tool 消息
            - 删掉工具结果不完整的 assistant 消息
        """
        # 第一步：收集所有"有主人"的工具调用编号
        parent_ids = set()
        for message in kept:
            for call in (message.get("tool_calls") or []):
                parent_ids.add(call.get("id"))

        # 第二步：删掉落单的 tool 消息
        stage_one = []
        for message in kept:
            if message.get("role") == "tool" and message.get("tool_call_id") not in parent_ids:
                continue
            stage_one.append(message)

        # 第三步：删掉工具结果不齐全的 assistant 消息
        answered_ids = {m.get("tool_call_id") for m in stage_one if m.get("role") == "tool"}
        stage_two = []
        for message in stage_one:
            calls = message.get("tool_calls") or []
            if calls and not all(c.get("id") in answered_ids for c in calls):
                continue
            stage_two.append(message)

        return stage_two


class LongTermMemory(object):
    """
    长期记忆 = 存在文件里的事实清单，跨会话、跨重启都还在。

    【它到底是什么】
    说白了就是一个 JSON 文件，长这样：
        {
          "facts": [
            {"id": 1, "text": "用户小林，职级 P5，市场部", "category": "用户信息",
             "created_at": "2026-10-18 09:00:00"}
          ]
        }

    需要用的时候，用检索器找出跟当前问题相关的几条，拼进提示词发给模型。
    就这么简单 —— 所谓"AI 记得我"，本质是"存下来 + 查出来 + 塞进去"。

    【生产环境怎么升级】
    把存储换成 Redis、PostgreSQL 或向量数据库即可，对外的 add / recall 接口不变。
    """

    def __init__(self, path, auto_save=True):
        """
        Args:
            path: JSON 文件路径
            auto_save: 每次新增事实是否立刻写盘。默认开启，防止程序意外退出丢数据。
        """
        self.path = path
        self.auto_save = auto_save
        self.facts = []
        self.corrupted = False       # 记忆文件是否损坏过（损坏不致命，重置即可）
        self.load()

    # ------------------------------------------------------------ 读写文件
    def load(self):
        """从文件加载记忆。文件不存在就是空记忆，文件损坏也当作空记忆处理。"""
        self.facts = []
        self.corrupted = False
        if os.path.isfile(self.path):
            try:
                with open(self.path, "r", encoding="utf-8") as file:
                    data = json.load(file)
                self.facts = data.get("facts", []) if isinstance(data, dict) else []
            except (ValueError, OSError):
                # 文件内容损坏（比如上次写到一半断电）。
                # 这里选择"当作没有记忆"而不是让整个 Agent 起不来 ——
                # 丢几条记忆是小事，Agent 完全无法启动是大事。
                self.facts = []
                self.corrupted = True
        return self

    def save(self):
        """
        把记忆写回文件。

        采用「先写临时文件，再原子替换」的方式：
        如果直接覆盖原文件，写到一半时程序崩溃，记忆就全丢了。
        先写 .tmp 再替换，要么全成功要么全不变。
        """
        parent = os.path.dirname(self.path)
        if parent and not os.path.isdir(parent):
            os.makedirs(parent)
        temp_path = self.path + ".tmp"
        with open(temp_path, "w", encoding="utf-8") as file:
            json.dump({"facts": self.facts}, file, ensure_ascii=False, indent=2)
        os.replace(temp_path, self.path)

    def reset(self):
        """清空全部记忆并删除文件。对应界面上的"忘记我"按钮。"""
        self.facts = []
        if os.path.isfile(self.path):
            os.remove(self.path)

    # ------------------------------------------------------------ 增删查
    def add(self, text, category="用户信息"):
        """
        记住一条事实。

        Args:
            text: 要记住的内容，例如 "用户小林，职级 P5"
            category: 分类标签，方便日后筛选，例如 用户信息 / 偏好 / 计划

        Returns:
            一句给人看的确认文字
        """
        text = (text or "").strip()
        if not text:
            return "错误：要记住的内容为空"

        # 去重：一模一样的事实不重复存，否则记忆文件会越滚越大、检索越来越乱
        for fact in self.facts:
            if fact["text"] == text:
                return "这条信息已经在记忆里了，无需重复保存。"

        self.facts.append({
            "id": len(self.facts) + 1,
            "text": text,
            "category": category,
            "created_at": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        })
        if self.auto_save:
            self.save()
        return "已记住：{0}".format(text)

    def recall(self, query, top_k=3):
        """
        按相关度检索记忆。

        复用了知识库那套 TF-IDF 检索器 —— 把每条记忆当成一个"文档片段"就行。
        这也再次说明：长期记忆和知识库，技术上是同一件事。

        Args:
            query: 想找什么，例如 "姓名 职级"
            top_k: 返回几条

        Returns:
            一段文字，直接拼进提示词给模型看
        """
        if not self.facts:
            return "（长期记忆为空，还不了解这位用户）"

        chunks = [{"doc": "memory", "heading": f["category"], "text": f["text"]}
                  for f in self.facts]
        hits = TfidfIndex(chunks).search(query, top_k=top_k)
        if not hits:
            return "（没有找到与「{0}」相关的记忆）".format(query)
        return "\n".join("- [{0}] {1}".format(c["heading"], c["text"]) for c, _ in hits)

    def all_text(self):
        """导出全部记忆，给人看的格式。界面上的"查看记忆"就用它。"""
        if not self.facts:
            return "(空)"
        return "\n".join("- [{0}] {1}（记于 {2}）".format(
            f["category"], f["text"], f["created_at"]) for f in self.facts)

    def __len__(self):
        return len(self.facts)
