# -*- coding: utf-8 -*-
"""
青橙科技「小橙」员工服务助手 —— Agent 包
==========================================

这是一个**完整但极简**的 Agent 实现，只依赖 requests 一个第三方库，
没有使用任何 Agent 框架。目的是让你看清 Agent 到底由哪几块拼成。

【包结构 = Agent 的组成部分】

    config.py      第 1 部分  配置中心    用哪个模型、密钥、路径、运行策略
    model.py       第 2 部分  大脑        调用大模型（重试、超时、用量统计、离线降级）
    knowledge.py   第 3 部分  知识库      文档切块 + TF-IDF 检索（RAG 的"检索"部分）
    memory.py      第 4 部分  记忆        短期记忆（会话内）+ 长期记忆（跨会话）
    tools.py       第 5 部分  手和脚      工具注册表、@tool 装饰器、文件沙箱
    prompts.py     第 6 部分  行为准则    系统提示词资产
    core.py        第 7 部分  编排循环    Agent 主体，把上面全部串起来
    server.py      可选部分   图形界面    HTTP 服务 + 网页聊天界面

【最小用法】

    from agent import Agent

    assistant = Agent()
    result = assistant.run("P5 员工去上海出差，住宿每晚最多能报多少？")
    print(result.answer)
    print(result.summary())     # 耗时 / 步数 / token / 轨迹文件
"""

from __future__ import annotations

from .config import Config
from .core import Agent, Result, print_event
from .knowledge import KnowledgeBase, TfidfIndex, tokenize
from .memory import LongTermMemory, ShortTermMemory
from .model import Model, ModelError
from .prompts import build_system_prompt
from .tools import Sandbox, ToolRegistry, build_schema, build_tools

__version__ = "1.0.0"

__all__ = [
    "Agent", "Result", "print_event",
    "Config",
    "Model", "ModelError",
    "KnowledgeBase", "TfidfIndex", "tokenize",
    "ShortTermMemory", "LongTermMemory",
    "Sandbox", "ToolRegistry", "build_schema", "build_tools",
    "build_system_prompt",
    "__version__",
]
