# -*- coding: utf-8 -*-
"""
============================================================
 第 7 部分：编排循环（Agent 主体）  core.py
============================================================

【这一部分负责什么】

把前面 6 个零件组装成一个能干活的 Agent。这是整个项目的心脏。

【Agent 到底是什么？一句话定义】

    ★ Agent = 大模型 + 工具 + 一个让它自己决定下一步的循环 ★

前两项都好理解，第三项是关键。看这个循环：

    ┌──────────────────────────────────────────────────┐
    │  while 步数没有超限:                               │
    │      ① 把对话历史 + 工具菜单，一起发给模型            │
    │      ② 模型返回的是"要调用工具"吗？                  │
    │           是 → ③ 执行工具，把结果塞回历史，回到 ①     │
    │           否 → ④ 它给出了最终答案，退出循环            │
    └──────────────────────────────────────────────────┘

【这个循环为什么重要】

    普通的"if-else 工作流"：每一步都是**你**提前写死的。
        先查数据库 → 再算价格 → 再生成报告    （顺序固定，遇到意外就卡住）

    Agent：下一步做什么，是**模型自己**根据当前情况决定的。
        它可能先查时间，发现是周末，于是改查加班规定，再算加班费……
        顺序是临场规划出来的，遇到工具报错还会自己换个办法重试。

    这种"自主决定下一步"的能力，才是 Agent 区别于普通自动化脚本的本质。

【三道必不可少的保险】

    自主是优点，也是风险。它可能规划错、绕圈子、把钱烧光。所以要加保险：

    保险 1：步数上限（max_steps）
        最多允许它自己折腾几轮，超过就强制中止。防止死循环产生天价账单。

    保险 2：重复调用检测
        连续两次用完全相同的参数调同一个工具，结果不可能变，直接掐断并提示它换思路。

    保险 3：工具异常兜底
        任何工具报错都不让程序崩溃，而是把错误文本回传给模型，让它自己纠错。

【这个循环的几个学名】

你在不同资料里会看到这些词，其实说的都是同一个东西：
    - Function Calling Loop（函数调用循环）
    - ReAct（Reasoning + Acting，推理与行动交替进行）
    - Agentic Loop
"""

from __future__ import annotations

import datetime
import json
import os
import re
import time

from . import prompts
from .config import Config
from .knowledge import KnowledgeBase
from .memory import LongTermMemory, ShortTermMemory
from .model import Model, ModelError
from .tools import Sandbox, build_tools


class Result(object):
    """
    一次任务的完整结果。

    为什么不直接返回一个字符串？
      因为交付出去的 Agent 必须"可交代"：花了多少钱、跑了几步、调了哪些工具、
      为什么失败。这些信息和答案本身同等重要。
      这个对象就是交付文档里说的「运行报告」。
    """

    def __init__(self, task):
        self.task = task                     # 原始任务
        self.answer = ""                     # 最终回答
        self.status = "unknown"              # completed 完成 / max_steps 超步数 / error 出错 / empty 空回答
        self.steps = []                      # 每一步的详细记录
        self.tool_calls = []                 # 扁平化的工具调用清单
        self.model_requests = 0              # 调用了几次模型
        self.total_tokens = 0                # 花了多少 token（= 花了多少钱）
        self.elapsed = 0.0                   # 耗时（秒）
        self.error = None                    # 出错时的错误信息
        self.trace_path = None               # 完整轨迹保存到了哪个文件

    @property
    def ok(self):
        """任务是否正常完成。"""
        return self.status == "completed"

    def summary(self):
        """生成一份人类可读的摘要，用有序字典保证显示顺序。"""
        return [
            ("任务", self.task[:60]),
            ("状态", self.status),
            ("耗时", "{0} 秒".format(self.elapsed)),
            ("模型请求", "{0} 次".format(self.model_requests)),
            ("工具调用", "{0} 次".format(len(self.tool_calls))),
            ("工具序列", " → ".join(c["name"] for c in self.tool_calls) or "无"),
            ("Token 消耗", self.total_tokens),
            ("轨迹文件", self.trace_path or "(未保存)"),
        ]

    def to_dict(self):
        """转成可写入 JSON 的字典。"""
        data = dict(self.summary())
        data["answer"] = self.answer
        data["steps"] = self.steps
        data["tool_calls"] = self.tool_calls
        data["error"] = self.error
        return data


class Agent(object):
    """
    一个可以直接交付使用的 Agent。

    最简用法：
        from agent import Agent

        assistant = Agent()
        result = assistant.run("P5 员工去上海出差，住宿每晚最多能报多少？")
        print(result.answer)

    多轮对话：
        session = assistant.new_session()
        assistant.run("我叫小林，职级 P5", session=session)
        assistant.run("那我去上海出差住宿能报多少？", session=session)   # 它记得你是 P5
    """

    def __init__(self, config=None, use_knowledge=True, use_memory=True,
                 extra_rules="", system_prompt=None, on_event=None, offline=False):
        """
        Args:
            config: Config 对象。不传则自动读取 .env 和环境变量
            use_knowledge: 是否启用知识库（关掉后不会注册 search_knowledge 工具）
            use_memory: 是否启用长期记忆
            extra_rules: 追加的项目定制规则，会写进系统提示词
            system_prompt: 完全自定义系统提示词。传了就忽略上面几项的自动拼装
            on_event: 事件回调函数，用于把执行过程实时推给界面或日志系统
            offline: 强制使用离线假模型（跑测试、验证流程时用，不联网不花钱）
        """
        self.config = config or Config()

        # ---------- 零件 1：沙箱（划定活动范围） ----------
        self.sandbox = Sandbox(self.config.workspace)

        # ---------- 零件 2：知识库 ----------
        self.knowledge = KnowledgeBase(self.config.kb_dir) if use_knowledge else None
        self.knowledge_warning = None
        if self.knowledge is not None and not self.knowledge.chunks:
            # 知识库为空不是致命错误，但必须明确提示。
            # 否则日后遇到"它总是说没找到"，你会很难想到是目录路径配错了。
            self.knowledge_warning = "知识库为空或目录不存在：{0}".format(self.config.kb_dir)

        # ---------- 零件 3：长期记忆 ----------
        self.memory = LongTermMemory(self.config.memory_file) if use_memory else None

        # ---------- 零件 4：工具 ----------
        self.tools = build_tools(self.sandbox, self.knowledge, self.memory)

        # ---------- 零件 5：系统提示词 ----------
        # 关键设计：能力声明由"实际注册了哪些工具"反推得出，而不是手写布尔值。
        # 这样从根上杜绝了"提示词里提到一个不存在的工具"这类低级但后果严重的错误。
        tool_names = set(self.tools.names())
        self.system_prompt = system_prompt or prompts.build_system_prompt(
            has_knowledge="search_knowledge" in tool_names,
            has_memory="save_memory" in tool_names and "recall_memory" in tool_names,
            has_calculator="calculator" in tool_names,
            has_files="save_file" in tool_names,
            has_time="get_time" in tool_names,
            extra_rules=extra_rules,
        )

        # ---------- 零件 6：大脑 ----------
        self.model = Model(self.config, offline=offline)

        # ---------- 可观测性 ----------
        # 把这个回调接到日志系统、WebSocket 或网页界面上，
        # 就能实时看到 Agent 每一步在想什么、做什么。
        self.on_event = on_event

    # ------------------------------------------------------------ 会话管理
    def new_session(self):
        """
        开一段新对话（独立的短期记忆）。

        每个用户、每个聊天窗口都应该有自己的 session，
        否则 A 用户会看到 B 用户的对话内容。
        """
        return ShortTermMemory(self.system_prompt, self.config.context_budget)

    # ------------------------------------------------------------ 主流程
    def run(self, task, session=None, verbose=False, on_event=None):
        """
        执行一个任务。这是整个项目最核心的方法。

        Args:
            task: 自然语言任务，例如 "帮我算一下 10 台笔记本 96 折多少钱"
            session: 传入 ShortTermMemory 则为多轮对话；不传则当作一次性任务
            verbose: 是否在终端实时打印每一步
            on_event: 本次调用的事件回调（优先级高于构造时传入的那个）

        Returns:
            Result 对象，包含答案和全部执行数据
        """
        result = Result(task)
        started_at = time.time()

        # 判断"有没有传 session"必须用 is None，不能用 `session or ...`。
        # 因为 ShortTermMemory 实现了 __len__，一个空会话的布尔值是 False，
        # 用 or 会导致每次调用都新建会话，多轮记忆彻底失效。
        if session is None:
            session = self.new_session()
        session.add_user(task)

        self._emit("task_start", {"task": task}, verbose, on_event)
        seen_calls = set()          # 保险 2 用：记录已经调用过的 (工具名, 参数)

        try:
            # ================= 这就是 Agent 的心脏 =================
            for step in range(1, self.config.max_steps + 1):      # 保险 1：步数上限

                # ---- ① 把历史和菜单发给模型 ----
                messages = session.messages()
                reply, usage = self.model.chat(messages, tools=self.tools.schemas())
                result.model_requests += 1
                result.total_tokens += usage.get("total_tokens", 0)

                # 必须把模型的回复原样加回历史。
                # 即使它这轮只是"点菜"（content 为空、只有 tool_calls），也要加，
                # 因为后面的工具结果必须能对应回这次点菜。
                session.add(reply)

                tool_calls = reply.get("tool_calls") or []

                # ---- ② / ④ 模型没有点菜 = 它认为任务完成了 ----
                if not tool_calls:
                    result.answer = (reply.get("content") or "").strip()
                    result.steps.append({
                        "step": step, "type": "answer",
                        "tokens": usage.get("total_tokens", 0),
                    })
                    result.status = "completed" if result.answer else "empty"
                    self._emit("answer", {"step": step, "answer": result.answer},
                               verbose, on_event)
                    break

                # ---- ③ 执行所有工具，把结果回灌，进入下一轮 ----
                step_record = {"step": step, "type": "tools", "calls": [],
                               "tokens": usage.get("total_tokens", 0)}
                self._emit("thinking", {
                    "step": step,
                    "tool_count": len(tool_calls),
                    "content": reply.get("content") or "",
                }, verbose, on_event)

                for call in tool_calls:
                    function_part = call.get("function") or {}
                    tool_name = function_part.get("name", "")
                    arguments = function_part.get("arguments") or "{}"
                    signature = (tool_name, arguments)

                    if signature in seen_calls:
                        # 保险 2：同样的工具 + 同样的参数，结果不会变，掐断它
                        output = ("错误：你刚刚用完全相同的参数调用过这个工具，结果不会改变。"
                                  "请换一个思路，或者直接向用户说明你遇到的困难。")
                        self._emit("blocked", {"name": tool_name, "reason": "重复调用"},
                                   verbose, on_event)
                    else:
                        seen_calls.add(signature)
                        output = self.tools.call(tool_name, arguments)   # 保险 3 在 call 内部

                    step_record["calls"].append({
                        "name": tool_name, "arguments": arguments, "result": output[:800],
                    })
                    result.tool_calls.append({
                        "step": step, "name": tool_name,
                        "arguments": arguments, "result": output[:800],
                    })

                    # 工具结果必须以 role="tool" 的身份回传，
                    # 并带上 tool_call_id，模型才知道这是对哪一次点菜的回应
                    session.add({
                        "role": "tool",
                        "tool_call_id": call.get("id"),
                        "content": output,
                    })
                    self._emit("tool", {
                        "step": step, "name": tool_name,
                        "arguments": arguments, "result": output[:300],
                    }, verbose, on_event)

                result.steps.append(step_record)
            else:
                # for 循环正常跑完都没有 break，说明撞到了步数上限
                result.status = "max_steps"
                result.answer = ("任务未能在 {0} 步内完成，已中止。已执行的工具：{1}".format(
                    self.config.max_steps,
                    " → ".join(c["name"] for c in result.tool_calls) or "无"))
                self._emit("max_steps", {"limit": self.config.max_steps}, verbose, on_event)

        except ModelError as exc:
            # 模型服务不可用（密钥错、网络断、限流耗尽重试）
            result.status = "error"
            result.error = str(exc)
            result.answer = "模型服务调用失败：{0}".format(exc)
            self._emit("error", {"error": str(exc)}, verbose, on_event)

        except Exception as exc:                                    # noqa: BLE001
            # 兜底：任何预料之外的错误都不能让程序崩溃，要给用户一句能看懂的话
            result.status = "error"
            result.error = "{0}: {1}".format(type(exc).__name__, exc)
            result.answer = "任务执行出现异常：{0}".format(result.error)
            self._emit("error", {"error": result.error}, verbose, on_event)

        result.elapsed = round(time.time() - started_at, 2)

        if self.config.save_trace:
            result.trace_path = self._save_trace(result)

        self._emit("task_end", dict(result.summary()), verbose, on_event)
        return result

    # ------------------------------------------------------------ 可观测性
    def _emit(self, kind, payload, verbose=False, on_event=None):
        """
        发出一个"事件"。

        事件种类：
            task_start  任务开始      thinking  模型决定要调工具了
            tool        工具执行完毕   blocked   拦截了一次重复调用
            answer      得到最终答案   max_steps 撞到步数上限
            error       出错          task_end  任务结束（带统计摘要）

        用途：
            - 命令行模式下打印彩色进度
            - 网页界面上实时显示"小橙正在查询知识库…"
            - 生产环境写进日志系统，便于排查问题
        """
        event = dict(payload)
        event["kind"] = kind
        event["time"] = datetime.datetime.now().strftime("%H:%M:%S")

        # 回调函数出错绝不能影响主流程 —— 日志挂了，任务还得继续跑
        for callback in (on_event, self.on_event):
            if callback is None:
                continue
            try:
                callback(event)
            except Exception:                                       # noqa: BLE001
                pass

        if verbose:
            print_event(event)

    def _save_trace(self, result):
        """
        把完整执行轨迹写入 JSON 文件。

        【为什么这是交付必需品】
        Agent 的输出是概率性的，同一个问题两次回答的措辞可能不同。
        一旦出现争议（"它上次明明说能报 800！"），轨迹是唯一能还原现场的证据。
        它同时也是排查问题、做效果评测的原始数据。

        注意：轨迹里写入的是**打码后的**配置快照，绝不含明文密钥。
        """
        if not os.path.isdir(self.config.trace_dir):
            os.makedirs(self.config.trace_dir)

        timestamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
        # 用任务前几个字做文件名，方便一眼认出是哪次运行
        slug = re.sub(r"[^\w\u4e00-\u9fff]+", "-", result.task)[:24].strip("-") or "task"
        path = os.path.join(self.config.trace_dir, "{0}-{1}.json".format(timestamp, slug))

        payload = {
            "config": self.config.public_snapshot(),
            "knowledge_stats": self.knowledge.stats() if self.knowledge else None,
            "result": result.to_dict(),
        }
        with open(path, "w", encoding="utf-8") as file:
            json.dump(payload, file, ensure_ascii=False, indent=2)
        return path

    # ------------------------------------------------------------ 交付辅助
    def tool_manifest(self):
        """生成能力清单，可直接贴进交付文档的「Agent 能做什么」表格。"""
        return self.tools.describe()

    def describe(self):
        """生成一份自检报告。每次交付前、每次改完配置后，都应该先看它一眼。"""
        stats = self.knowledge.stats() if self.knowledge else {
            "documents": 0, "chunks": 0, "vocab_size": 0}
        return "\n".join([
            "======== Agent 自检报告 ========",
            self.config.describe(),
            "知识库   : {0} 篇文档 / {1} 个片段 / 词表 {2} 个词".format(
                stats.get("documents", 0), stats.get("chunks", 0), stats.get("vocab_size", 0)),
            "长期记忆 : {0} 条事实".format(len(self.memory) if self.memory else 0),
            "沙箱目录 : {0}".format(self.sandbox.root),
            "工具数量 : {0} 个".format(len(self.tools.names())),
            "工具清单 : {0}".format(", ".join(self.tools.names())),
        ])


# ============================================================ 终端打印
def print_event(event):
    """把事件打印成人类易读的格式。命令行模式（verbose=True）时使用。"""
    kind = event.get("kind")

    if kind == "task_start":
        print("\n[任务] " + str(event["task"]))
    elif kind == "thinking":
        print("  第 {0} 轮 → 决定调用 {1} 个工具".format(event["step"], event["tool_count"]))
    elif kind == "tool":
        arguments = str(event["arguments"])
        if len(arguments) > 90:
            arguments = arguments[:90] + "..."
        output = str(event["result"]).replace("\n", " ")
        if len(output) > 110:
            output = output[:110] + "..."
        print("    ├─ {0}({1})".format(event["name"], arguments))
        print("    └─ {0}".format(output))
    elif kind == "blocked":
        print("    [拦截] 重复调用 " + str(event["name"]))
    elif kind == "answer":
        print("\n[回答] " + str(event["answer"]))
    elif kind == "max_steps":
        print("\n[中止] 已达最大步数 {0}".format(event["limit"]))
    elif kind == "error":
        print("\n[错误] " + str(event["error"]))
