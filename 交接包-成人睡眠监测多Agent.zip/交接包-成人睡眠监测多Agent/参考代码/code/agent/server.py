# -*- coding: utf-8 -*-
"""
============================================================
 可选部分：网页服务  server.py
============================================================

【这一部分负责什么】

给 Agent 套一个网页聊天界面。启动后浏览器打开就能用，不用敲命令行。

★ 这是**可选**的。Agent 的核心能力全在前面 7 个部分里，
  没有这个文件，Agent 照样能通过 run_cli.py 正常工作。
  加它的唯一理由是：给不懂命令行的同事用，以及演示时更直观。

【为什么用 Python 标准库，而不是 FastAPI / Flask】

    零依赖。你不需要再装任何东西，也不会遇到版本冲突。
    http.server 是 Python 自带的，虽然简陋，但足够跑一个内部工具。

    生产环境建议换成 FastAPI + uvicorn，能得到：
    异步并发、自动接口文档、成熟的鉴权中间件、更好的性能。
    换的时候只需要把本文件的路由搬过去，Agent 本体一行都不用改。

【Agent 的四种"自动化执行方式"】

    ① 人机对话    run_cli.py 的交互模式      —— 用户主动问
    ② 网页界面    本文件 server.py           —— 用户主动问（更友好）
    ③ 被系统调用  本文件的 /api/chat 接口    —— 别的程序主动问
    ④ 定时/事件触发 系统计划任务、Webhook     —— 时间到了或有事发生，自动跑

    四种方式共用同一个 Agent 对象，区别只在"谁按下开始键"。

【接口一览】

    GET  /                     网页界面
    GET  /api/health           健康检查（含配置快照，不含密钥）
    GET  /api/tools            能力清单
    GET  /api/memory           查看长期记忆
    POST /api/memory/clear     清空长期记忆
    POST /api/kb/reload        知识库热更新（改完文档不用重启服务）
    POST /api/session/new      开启新会话
    POST /api/chat             对话（以流式方式逐步返回执行过程）
"""

from __future__ import annotations

import json
import os
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

from .core import Agent
from .config import Config

# ------------------------------------------------------------ 全局状态
# 整个服务共用一个 Agent 实例（知识库和记忆只加载一次，避免每个请求都重建索引）
AGENT = None

# session_id → ShortTermMemory。每个浏览器窗口一个，互不干扰。
SESSIONS = {}
SESSION_LOCK = threading.Lock()
MAX_SESSIONS = 50          # 上限，防止内存被无限撑大
SESSION_TTL = 3600         # 一小时不活跃就回收

# Agent 运行锁。本演示服务串行处理对话请求：
# 一是避免多个请求同时改写统计数据，二是大模型调用本身就是瓶颈，
# 并发也提不上速。生产环境应该换成任务队列 + 多工作进程。
RUN_LOCK = threading.Lock()

STATIC_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")


def create_agent(config=None):
    """创建全局 Agent 实例。服务启动时调用一次。"""
    global AGENT
    AGENT = Agent(config=config or Config())
    return AGENT


def get_session(session_id):
    """取出（或新建）一个会话，并清理过期的旧会话。"""
    now = time.time()
    with SESSION_LOCK:
        # 回收过期会话
        expired = [k for k, v in SESSIONS.items() if now - v["touched"] > SESSION_TTL]
        for key in expired:
            del SESSIONS[key]

        # 会话数量超限时，淘汰最久没用的那个
        if len(SESSIONS) >= MAX_SESSIONS and session_id not in SESSIONS:
            oldest = min(SESSIONS.items(), key=lambda kv: kv[1]["touched"])
            del SESSIONS[oldest[0]]

        entry = SESSIONS.get(session_id)
        if entry is None:
            entry = {"memory": AGENT.new_session(), "created": now}
            SESSIONS[session_id] = entry
        entry["touched"] = now
        return entry["memory"]


# ------------------------------------------------------------ HTTP 处理器
class RequestHandler(BaseHTTPRequestHandler):
    """处理所有 HTTP 请求。"""

    server_version = "QingChengAgent/1.0"

    # ---------- 基础工具 ----------
    def log_message(self, fmt, *args):
        """精简默认日志，只打印方法和路径，避免刷屏。"""
        print("  [{0}] {1}".format(self.log_date_time_string(), fmt % args))

    def _authorized(self):
        """
        校验访问口令。

        没有设置 WEBUI_TOKEN 时不校验（只适合本机演示）。
        ★ 一旦把服务暴露给局域网或公网，必须设置口令 ★
        """
        token = (AGENT.config.settings.get("WEBUI_TOKEN") or "").strip()
        if not token:
            return True
        provided = self.headers.get("X-Agent-Token", "")
        if not provided:
            query = urlparse(self.path).query
            for part in query.split("&"):
                if part.startswith("token="):
                    provided = part[6:]
        return provided == token

    def _send_json(self, payload, status=200):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _send_html(self, html, status=200):
        body = html.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read_body(self):
        length = int(self.headers.get("Content-Length") or 0)
        if length <= 0:
            return {}
        raw = self.rfile.read(length)
        try:
            data = json.loads(raw.decode("utf-8"))
            return data if isinstance(data, dict) else {}
        except (ValueError, UnicodeDecodeError):
            return {}

    # ---------- 路由 ----------
    def do_OPTIONS(self):
        """处理浏览器的跨域预检请求。"""
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, X-Agent-Token")
        self.end_headers()

    def do_GET(self):
        path = urlparse(self.path).path

        if path in ("/", "/index.html"):
            self._serve_index()
        elif path == "/api/health":
            self._api_health()
        elif path == "/api/tools":
            self._api_tools()
        elif path == "/api/memory":
            self._api_memory()
        elif path == "/api/prompt":
            self._api_prompt()
        else:
            self._send_json({"error": "未知路径 " + path}, 404)

    def do_POST(self):
        path = urlparse(self.path).path

        if not self._authorized():
            self._send_json({"error": "访问口令不正确"}, 401)
            return

        if path == "/api/chat":
            self._api_chat()
        elif path == "/api/session/new":
            self._send_json({"session_id": uuid.uuid4().hex})
        elif path == "/api/memory/clear":
            if AGENT.memory:
                AGENT.memory.reset()
            self._send_json({"ok": True, "message": "长期记忆已清空"})
        elif path == "/api/kb/reload":
            stats = None
            if AGENT.knowledge:
                stats = AGENT.knowledge.reload().stats()
            self._send_json({"ok": True, "knowledge": stats})
        else:
            self._send_json({"error": "未知路径 " + path}, 404)

    # ---------- 各接口实现 ----------
    def _serve_index(self):
        """返回网页界面。"""
        index_path = os.path.join(STATIC_DIR, "index.html")
        if not os.path.isfile(index_path):
            self._send_html("<h1>界面文件缺失</h1><p>找不到 agent/static/index.html</p>", 500)
            return
        with open(index_path, "r", encoding="utf-8") as file:
            self._send_html(file.read())

    def _api_health(self):
        """健康检查。前端启动时先调它，确认后端活着、配置对不对。"""
        if not self._authorized():
            self._send_json({"error": "访问口令不正确"}, 401)
            return
        stats = AGENT.knowledge.stats() if AGENT.knowledge else {}
        self._send_json({
            "ok": True,
            "config": AGENT.config.public_snapshot(),     # 已打码，不含明文密钥
            "knowledge": stats,
            "knowledge_warning": AGENT.knowledge_warning,
            "memory_facts": len(AGENT.memory) if AGENT.memory else 0,
            "tools": AGENT.tools.names(),
            "workspace": AGENT.sandbox.root,
        })

    def _api_tools(self):
        if not self._authorized():
            self._send_json({"error": "访问口令不正确"}, 401)
            return
        self._send_json({"ok": True, "tools": AGENT.tool_manifest()})

    def _api_memory(self):
        if not self._authorized():
            self._send_json({"error": "访问口令不正确"}, 401)
            return
        facts = AGENT.memory.facts if AGENT.memory else []
        self._send_json({"ok": True, "facts": facts})

    def _api_prompt(self):
        """返回系统提示词。让使用者能看到"这个 Agent 被定了哪些规矩"。"""
        if not self._authorized():
            self._send_json({"error": "访问口令不正确"}, 401)
            return
        self._send_json({"ok": True, "system_prompt": AGENT.system_prompt})

    def _api_chat(self):
        """
        对话接口，采用「流式返回」。

        为什么要流式？
          一次任务可能要跑 20 秒（查知识库 → 计算 → 写文件 → 总结）。
          如果等全部跑完再返回，用户会盯着空白屏幕以为卡死了。
          流式返回让界面能实时显示"小橙正在查询知识库…""正在计算…"，
          体验完全不同，也让人直观理解 Agent 是怎么工作的。

        实现方式：SSE（Server-Sent Events）。
          就是保持连接不关闭，每发生一件事就写一行
              event: 事件名
              data: {JSON}
          然后立即 flush 出去。
        """
        body = self._read_body()
        message = (body.get("message") or "").strip()
        session_id = body.get("session_id") or uuid.uuid4().hex

        if not message:
            self._send_json({"error": "消息内容为空"}, 400)
            return

        # 准备好流式响应的头部。
        # 注意这里必须是 Connection: close ——
        # 流式响应无法预先知道内容长度，只能靠"关闭连接"来告诉浏览器"发完了"。
        # 如果写成 keep-alive，浏览器会一直等下去，界面表现为永远转圈。
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-cache, no-transform")
        self.send_header("Connection", "close")
        self.send_header("X-Accel-Buffering", "no")      # 告诉反向代理不要缓冲
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.close_connection = True

        def send_event(event):
            """把一个事件推给浏览器。连接断了就静默忽略，不能让主流程崩掉。"""
            try:
                payload = json.dumps(event, ensure_ascii=False)
                self.wfile.write("event: {0}\ndata: {1}\n\n".format(
                    event.get("kind", "message"), payload).encode("utf-8"))
                self.wfile.flush()
            except Exception:                                       # noqa: BLE001
                pass

        session = get_session(session_id)

        # 先告诉前端会话 id，它要用这个 id 维持多轮对话
        send_event({"kind": "session", "session_id": session_id})

        with RUN_LOCK:
            result = AGENT.run(message, session=session, on_event=send_event)

        # 最后一个事件：完整结果 + 统计信息
        send_event({
            "kind": "done",
            "answer": result.answer,
            "status": result.status,
            "elapsed": result.elapsed,
            "tokens": result.total_tokens,
            "model_requests": result.model_requests,
            "tool_calls": [{"name": c["name"], "arguments": c["arguments"],
                            "result": c["result"][:600]} for c in result.tool_calls],
        })


# ------------------------------------------------------------ 启动
def serve(host="127.0.0.1", port=8000, config=None):
    """启动网页服务。"""
    agent = create_agent(config)

    print("=" * 66)
    print("  青橙科技「小橙」员工服务助手 · 网页界面")
    print("=" * 66)
    print(agent.describe())
    if agent.knowledge_warning:
        print("\n[!] " + agent.knowledge_warning)
    token = (agent.config.settings.get("WEBUI_TOKEN") or "").strip()
    print("\n  访问地址 : http://{0}:{1}/".format(host, port))
    print("  访问口令 : {0}".format(token if token else "(未设置，仅限本机演示)"))
    print("  停止服务 : 按 Ctrl + C")
    print("=" * 66 + "\n")

    httpd = ThreadingHTTPServer((host, port), RequestHandler)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n服务已停止。")
    finally:
        httpd.server_close()
