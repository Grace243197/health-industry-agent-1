# -*- coding: utf-8 -*-
"""
============================================================
 第 1 部分：配置中心  config.py
============================================================

【这一部分负责什么】

把 Agent 所有"可以调的旋钮"集中放在一个地方：
用哪个模型、密钥是什么、最多跑几步、文件放在哪。

【为什么要单独一个文件】

如果没有它，这些参数会散落在几十个文件的各个角落。
将来要换模型、要改路径，就得整个项目搜一遍，改漏一处就出 bug。
集中管理之后，换模型只改一行，交接给别人时也只有一份"配置说明书"要看。

【配置从哪里读】

按优先级从高到低：
    1. 系统环境变量      适合服务器部署、CI 流水线
    2. 项目里的 .env 文件  适合本地开发（把 .env.example 复制成 .env 再填）
    3. 代码里的默认值     兜底

★ 安全铁律：密钥永远不要写死在代码里，也永远不要提交到 git。
  .env 必须写进 .gitignore，仓库里只放 .env.example 模板。
"""

from __future__ import annotations

import os

# 项目根目录 = 本文件的上一级（也就是 code/ 目录）
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def read_env_file(path):
    """
    读取 .env 文件，返回一个字典。

    .env 文件的格式非常简单，一行一条 "名字=值"：
        AGENT_API_KEY=sk-xxxxxxxx
        AGENT_MODEL=qwen-plus
    以 # 开头的行是注释，空行会被跳过。

    这里自己写了 20 行解析代码，是为了让项目**零第三方依赖**。
    如果你已经在用 python-dotenv，直接替换这个函数即可，其他代码不用动。
    """
    values = {}
    if not os.path.isfile(path):
        return values

    with open(path, "r", encoding="utf-8") as file:
        for raw_line in file.read().splitlines():
            line = raw_line.strip()
            # 跳过空行和注释行
            if not line or line.startswith("#") or "=" not in line:
                continue
            name, _, value = line.partition("=")
            # 去掉值两侧可能存在的引号（有人习惯写 KEY="value"）
            values[name.strip()] = value.strip().strip('"').strip("'")
    return values


class Config(object):
    """Agent 的全部可调参数。整个项目只创建一次，然后到处传递。"""

    def __init__(self, base_dir=None, **overrides):
        """
        Args:
            base_dir: 项目根目录，默认自动定位到 code/ 目录
            overrides: 临时覆盖某些配置，主要给测试用。
                       例如 Config(AGENT_MODEL="别的模型")
        """
        self.base_dir = base_dir or BASE_DIR

        # ---------- 第一步：把三个来源的配置合并成一个字典 ----------
        settings = {}
        settings.update(read_env_file(os.path.join(self.base_dir, ".env")))
        settings.update({k: v for k, v in os.environ.items() if v})
        settings.update({k: v for k, v in overrides.items() if v is not None})
        self.settings = settings

        def get(name, default=None):
            """取一个配置项，转成字符串并去掉首尾空格。"""
            value = settings.get(name)
            if value is None or str(value).strip() == "":
                return default
            return str(value).strip()

        # ---------- 第二步：模型接入的三要素 ----------
        # 这三项决定了"Agent 的大脑是谁"。换一个供应商，通常只改这三行配置。
        self.api_key = get("AGENT_API_KEY")            # 你的 API 密钥
        self.base_url = get("AGENT_BASE_URL",          # 你的接口地址
                          "https://dashscope.aliyuncs.com/compatible-mode/v1")
        self.model = get("AGENT_MODEL", "qwen-plus")    # 你的模型名称

        # ---------- 第三步：运行策略 ----------
        # temperature：随机性。0 最"死板"每次答案几乎一样，1 最"活泼"。
        #              查制度、报数字这类任务要**低**（0~0.3），写文案才调高。
        self.temperature = float(get("AGENT_TEMPERATURE", "0.2"))

        # max_tokens：单次回复最长多少 token。设上限是为了防止模型啰嗦、也防止费用失控。
        self.max_tokens = int(get("AGENT_MAX_TOKENS", "1500"))

        # timeout：一次网络请求最多等多久（秒）。不设的话，网络卡住会让程序永远挂着。
        self.timeout = int(get("AGENT_TIMEOUT", "120"))

        # max_retries：请求失败后重试几次。网络抖动、服务限流都很常见，重试能救回大部分。
        self.max_retries = int(get("AGENT_MAX_RETRIES", "2"))

        # max_steps：★最重要的一道保险★
        #   Agent 是"自己决定下一步做什么"的，理论上可能陷入死循环：
        #   查一次 → 不满意 → 再查一次 → 还不满意 → ……
        #   每循环一次就要花一次钱。这个上限就是"最多允许它自己折腾几轮"。
        self.max_steps = int(get("AGENT_MAX_STEPS", "8"))

        # context_budget：一次请求最多携带多少字符的历史对话。
        #   历史越长 → 越贵、越慢、模型越容易被无关内容干扰。所以要设预算。
        self.context_budget = int(get("AGENT_CONTEXT_BUDGET", "24000"))

        # enable_thinking：是否开启"深度思考"模式。
        #   这是**部分服务商**（例如通义千问 qwen3 系列）才有的开关，不是通用标准。
        #   留空 = 不发送这个字段，由服务商用它自己的默认值。
        #   填 true / false = 明确发送。
        #   为什么可能要关掉：开启后模型会先长篇思考再回答，同一个问题的耗时和
        #   token 消耗可能高出几十倍。工具型 Agent 追求的是快和稳，通常建议关闭；
        #   需要复杂多步推理时再打开。
        raw_thinking = get("AGENT_ENABLE_THINKING")
        if raw_thinking is None:
            self.enable_thinking = None              # 不发送该字段
        else:
            self.enable_thinking = raw_thinking.lower() in ("1", "true", "yes", "on")

        # ---------- 第四步：路径 ----------
        # 知识库目录：放你的资料文档（.md / .txt）
        self.kb_dir = get("AGENT_KB_DIR", os.path.join(self.base_dir, "knowledge_base"))
        # 沙箱目录：Agent 唯一被允许读写文件的地方
        self.workspace = get("AGENT_WORKSPACE", os.path.join(self.base_dir, "workspace"))
        # 长期记忆文件：一个普通的 JSON 文件
        self.memory_file = get("AGENT_MEMORY_FILE", os.path.join(self.base_dir, "memory.json"))
        # 轨迹目录：每次任务的完整执行记录，用于复盘和验收
        self.trace_dir = get("AGENT_TRACE_DIR", os.path.join(self.base_dir, "traces"))
        # 是否保存轨迹
        self.save_trace = get("AGENT_SAVE_TRACE", "true").lower() in ("1", "true", "yes", "on")

    # ------------------------------------------------------------ 几个便利方法

    @property
    def online(self):
        """
        是否具备联网调用真实模型的条件。

        没有密钥时返回 False，Agent 会自动切换到「试用模式」（离线假模型），
        这样你在还没申请到密钥时，也能先把界面和流程跑通看看。
        """
        return bool(self.api_key)

    def masked_key(self):
        """把密钥打码后返回，用于打印和写日志。完整密钥绝不能出现在任何输出里。"""
        if not self.api_key:
            return "(未配置)"
        if len(self.api_key) <= 12:
            return "*" * len(self.api_key)
        return self.api_key[:6] + "*" * 8 + self.api_key[-4:]

    def public_snapshot(self):
        """
        生成一份"可以安全公开"的配置快照。

        用途：写进日志、写进评测报告、贴进交付文档。
        关键点：里面只有打码后的密钥，没有明文。
        """
        return {
            "base_url": self.base_url,
            "model": self.model,
            "api_key": self.masked_key(),
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
            "max_steps": self.max_steps,
            "context_budget": self.context_budget,
            "enable_thinking": self.enable_thinking,
            "online": self.online,
        }

    def describe(self):
        """生成一段人类可读的配置说明，启动时打印出来，方便确认当前连的是哪个模型。"""
        if self.enable_thinking is None:
            thinking = "未指定（用服务商默认值）"
        else:
            thinking = "开启" if self.enable_thinking else "关闭"
        return "\n".join([
            "接口地址 : {0}".format(self.base_url),
            "模型名称 : {0}".format(self.model),
            "API 密钥 : {0}".format(self.masked_key()),
            "运行模式 : {0}".format("真实模型" if self.online else "试用模式（未配置密钥，使用离线假模型）"),
            "策略参数 : 最多 {0} 步 / 温度 {1} / 单次上限 {2} token / 超时 {3} 秒".format(
                self.max_steps, self.temperature, self.max_tokens, self.timeout),
            "深度思考 : {0}".format(thinking),
        ])
