# -*- coding: utf-8 -*-
"""
============================================================
 可选部分：网页界面启动入口  run_webui.py
============================================================

★ 这个文件是**可选**的 ★
Agent 的核心能力全在 agent/ 目录里，不启动网页界面也完全能用命令行工作：
    python run_cli.py

启动网页界面的唯一理由是：让不懂命令行的同事也能用，以及演示时更直观。

【用法】
    python run_webui.py                    默认 http://127.0.0.1:8000
    python run_webui.py --port 9000        换端口
    python run_webui.py --host 0.0.0.0     允许同网段的其他电脑访问
                                           （此时务必在 .env 里设置 WEBUI_TOKEN）

【前置条件】
    1. 已把 .env.example 复制成 .env 并填好你的 API 密钥
       （没填也能启动，会进入"试用模式"，用离线假模型响应）
    2. 已安装依赖：pip install -r requirements.txt
"""

from __future__ import annotations

import argparse
import sys

from agent.config import Config
from agent.server import serve


def main():
    # Windows 终端默认编码可能不是 UTF-8，中文会显示成乱码，这里统一切换
    if sys.platform == "win32":
        for stream in (sys.stdin, sys.stdout, sys.stderr):
            try:
                stream.reconfigure(encoding="utf-8", errors="replace")
            except Exception:                                       # noqa: BLE001
                pass

    parser = argparse.ArgumentParser(description="启动 Agent 网页界面（可选组件）")
    parser.add_argument("--host", default=None,
                        help="监听地址，默认取 .env 里的 WEBUI_HOST，再默认 127.0.0.1")
    parser.add_argument("--port", type=int, default=None,
                        help="监听端口，默认取 .env 里的 WEBUI_PORT，再默认 8000")
    arguments = parser.parse_args()

    config = Config()
    host = arguments.host or config.settings.get("WEBUI_HOST") or "127.0.0.1"
    port = arguments.port or int(config.settings.get("WEBUI_PORT") or 8000)

    # 对外暴露时如果没设口令，明确警告一次
    if host not in ("127.0.0.1", "localhost") and not (config.settings.get("WEBUI_TOKEN") or "").strip():
        print("[!] 警告：你正在把服务暴露给其他电脑，但没有设置 WEBUI_TOKEN 访问口令。")
        print("    任何人都能调用你的模型、消耗你的额度、读取知识库。请先在 .env 里设置口令。\n")

    serve(host=host, port=port, config=config)


if __name__ == "__main__":
    main()
