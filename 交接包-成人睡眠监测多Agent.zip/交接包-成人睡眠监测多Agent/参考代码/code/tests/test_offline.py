# -*- coding: utf-8 -*-
"""
============================================================
 离线单元测试  tests/test_offline.py
============================================================

★ 全部测试都不联网、不消耗 API 额度、不修改真实文件 ★

【为什么 Agent 项目更需要单元测试】

    Agent 的行为不确定，你没法靠"手动跑一遍看着挺好"来保证质量。
    所以要把测试分成两层：

        单元测试（本文件）  →  保证"零件没坏"
                               检索、沙箱、记忆、循环控制这些**确定性**逻辑
                               每次改代码都跑，秒级完成，零成本

        验收评测（evaluate.py）→ 保证"整体够聪明"
                               回答质量这类**不确定性**输出
                               交付前跑，要花时间和费用

    两层缺一不可：只有单元测试，你不知道它答得对不对；
    只有评测，出了问题你不知道该修哪个零件。

【运行方法】
    在 code 目录下执行：
        python -m unittest discover -s tests -v
"""

from __future__ import annotations

import json
import os
import re
import shutil
import sys
import tempfile
import unittest

# 保证能 import 到 code 目录下的 agent 包
CODE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if CODE_DIR not in sys.path:
    sys.path.insert(0, CODE_DIR)

from agent.config import Config                                  # noqa: E402
from agent.core import Agent                                     # noqa: E402
from agent.knowledge import KnowledgeBase, TfidfIndex, tokenize   # noqa: E402
from agent.memory import LongTermMemory, ShortTermMemory          # noqa: E402
from agent.model import ModelError                               # noqa: E402
from agent.prompts import build_system_prompt                    # noqa: E402
from agent.tools import Sandbox, ToolRegistry, build_schema       # noqa: E402

KB_DIR = os.path.join(CODE_DIR, "knowledge_base")


# ============================================================ 测试辅助
def make_tool_call(name, arguments, call_id="c1"):
    """构造一个"模型要求调用工具"的消息片段。"""
    return {
        "id": call_id,
        "type": "function",
        "function": {"name": name, "arguments": json.dumps(arguments, ensure_ascii=False)},
    }


def scripted_model(replies):
    """
    按顺序吐出预设回复的假模型，用来精确控制 Agent 循环的走向。

    replies 的每一项可以是：
        - 一个消息字典           → 用量用默认值
        - (消息字典, 用量) 元组   → 同时指定用量
    """
    state = {"index": 0}

    def fake(messages, tools=None):
        index = state["index"]
        state["index"] += 1
        item = replies[min(index, len(replies) - 1)]
        if isinstance(item, tuple):
            return item[0], (item[1] or {"total_tokens": 10})
        return item, {"total_tokens": 10}
    return fake


def make_agent(temp_dir, **kwargs):
    """
    在临时目录里造一个完全隔离的 Agent。

    隔离很重要：测试绝不能碰真实的 workspace 和 memory.json，
    否则跑一次测试就把用户的记忆文件改坏了。
    """
    config = Config(
        base_dir=temp_dir,
        AGENT_KB_DIR=KB_DIR,
        AGENT_WORKSPACE=os.path.join(temp_dir, "workspace"),
        AGENT_MEMORY_FILE=os.path.join(temp_dir, "memory.json"),
        AGENT_TRACE_DIR=os.path.join(temp_dir, "traces"),
        AGENT_MAX_STEPS=str(kwargs.pop("max_steps", 6)),
        AGENT_SAVE_TRACE="true",
    )
    return Agent(config=config, offline=True, **kwargs)


# ============================================================ 一、分词与检索
class TestTokenize(unittest.TestCase):
    """考察"文字变数字"的第一步：切词。"""

    def test_chinese_bigram(self):
        self.assertEqual(tokenize("报销"), ["报销"])
        self.assertEqual(tokenize("报销标准"), ["报销", "销标", "标准"])

    def test_english_and_number_kept_whole(self):
        tokens = tokenize("青橙 Book 14 售价 5299")
        self.assertIn("book", tokens)     # 统一小写，Book 和 book 视为同一个词
        self.assertIn("5299", tokens)     # 数字不被拆成 5、2、9、9
        self.assertIn("青橙", tokens)

    def test_empty_input(self):
        self.assertEqual(tokenize(""), [])
        self.assertEqual(tokenize(None), [])


class TestKnowledgeBase(unittest.TestCase):
    """考察知识库的切块与检索质量。"""

    @classmethod
    def setUpClass(cls):
        cls.kb = KnowledgeBase(KB_DIR)

    def test_documents_loaded(self):
        stats = self.kb.stats()
        self.assertEqual(stats["documents"], 5)
        self.assertGreater(stats["chunks"], 20)
        self.assertGreater(stats["vocab_size"], 100)

    def test_heading_path_preserved(self):
        """切块必须保留标题路径，否则片段失去上下文、无法做引用标注。"""
        for chunk in self.kb.chunks:
            self.assertIn("doc", chunk)
            self.assertTrue(chunk["heading"])

    def test_search_finds_reimbursement_rule(self):
        hits = self.kb.search("住宿报销标准", top_k=3)
        self.assertTrue(hits)
        joined = " ".join(c["text"] for c, _ in hits)
        self.assertIn("520", joined)

    def test_search_finds_tax_id(self):
        joined = " ".join(c["text"] for c, _ in self.kb.search("发票抬头 税号", top_k=3))
        self.assertIn("91330100MA2QK4X67T", joined)

    def test_search_finds_annual_leave(self):
        joined = " ".join(c["text"] for c, _ in self.kb.search("年假天数", top_k=3))
        self.assertIn("15", joined)

    def test_scores_sorted_descending(self):
        scores = [score for _, score in self.kb.search("设备报修", top_k=5)]
        self.assertEqual(scores, sorted(scores, reverse=True))

    def test_irrelevant_english_query_returns_empty(self):
        """完全无关的查询应返回空，而不是硬凑几个结果骗模型。"""
        self.assertEqual(self.kb.search("quidditch hogwarts zzz", top_k=3), [])

    def test_irrelevant_chinese_query_low_score(self):
        """中文无关查询：即使字级组合偶然撞上，相关度也应该极低。"""
        for _, score in self.kb.search("霍格沃茨魁地奇比赛", top_k=3):
            self.assertLess(score, 0.05)

    def test_format_hits_requires_honesty(self):
        """没有检索结果时，返回的文字必须明确要求模型如实说"没找到"。"""
        text = self.kb.format_hits([])
        self.assertIn("未找到", text)
        self.assertIn("严禁编造", text)

    def test_format_hits_includes_source(self):
        hits = self.kb.search("年假", top_k=1)
        text = self.kb.format_hits(hits)
        self.assertIn("出处：", text)
        self.assertIn("相关度", text)

    def test_idf_prefers_rare_words(self):
        """TF-IDF 的核心直觉：越罕见的词权重越高。"""
        chunks = [
            {"doc": "a", "heading": "", "text": "公司的报销制度规定了报销流程"},
            {"doc": "b", "heading": "", "text": "公司的产品手册介绍了公司产品"},
            {"doc": "c", "heading": "", "text": "公司的常见问题解答了公司政策"},
        ]
        index = TfidfIndex(chunks)
        self.assertGreater(index.idf.get("制度", 0), index.idf.get("公司", 0))

    def test_missing_directory_yields_empty_kb(self):
        """知识库目录不存在时不应报错，而是得到一个空知识库。"""
        kb = KnowledgeBase(os.path.join(CODE_DIR, "这个目录不存在"))
        self.assertEqual(kb.chunks, [])
        self.assertEqual(kb.search("任何内容"), [])


# ============================================================ 二、沙箱与安全
class TestSandbox(unittest.TestCase):
    """考察文件操作的权限边界。"""

    def setUp(self):
        self.temp_dir = tempfile.mkdtemp(prefix="agent-test-")
        self.sandbox = Sandbox(os.path.join(self.temp_dir, "ws"))

    def tearDown(self):
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_normal_path_allowed(self):
        self.assertTrue(self.sandbox.resolve("a.txt").startswith(self.sandbox.root))

    def test_nested_path_allowed(self):
        self.assertTrue(self.sandbox.resolve("out/2026/report.md").startswith(self.sandbox.root))

    def test_parent_traversal_blocked(self):
        with self.assertRaises(PermissionError):
            self.sandbox.resolve("../../.env")

    def test_absolute_path_outside_blocked(self):
        with self.assertRaises(PermissionError):
            self.sandbox.resolve("C:/Windows/win.ini")

    def test_private_key_blocked(self):
        with self.assertRaises(PermissionError):
            self.sandbox.resolve("../../../.ssh/id_rsa")

    def test_empty_path_rejected(self):
        with self.assertRaises(ValueError):
            self.sandbox.resolve("")
        with self.assertRaises(ValueError):
            self.sandbox.resolve(None)

    def test_workspace_auto_created(self):
        self.assertTrue(os.path.isdir(self.sandbox.root))


class TestToolSafety(unittest.TestCase):
    """考察工具层的安全防护与健壮性。"""

    def setUp(self):
        self.temp_dir = tempfile.mkdtemp(prefix="agent-test-")
        self.agent = make_agent(self.temp_dir)
        self.tools = self.agent.tools

    def tearDown(self):
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    # ---- 计算器 ----
    def test_calculator_correct(self):
        self.assertEqual(self.tools.call("calculator", '{"expression": "5299 * 0.96"}'),
                         "5087.04")

    def test_calculator_blocks_code_injection(self):
        output = self.tools.call(
            "calculator", json.dumps({"expression": "__import__('os').system('dir')"}))
        self.assertTrue(output.startswith("错误"), output)

    def test_calculator_blocks_builtin_access(self):
        output = self.tools.call("calculator", json.dumps({"expression": "open('x')"}))
        self.assertTrue(output.startswith("错误"), output)

    def test_calculator_float_rounded(self):
        """浮点运算的尾巴要被修掉，否则用户会看到 0.30000000000000004 这种东西。"""
        self.assertEqual(self.tools.call("calculator", '{"expression": "0.1 + 0.2"}'), "0.3")

    # ---- 文件 ----
    def test_read_file_cannot_escape(self):
        output = self.tools.call("read_file", '{"path": "../../.env"}')
        self.assertTrue(output.startswith("权限拒绝"), output)

    def test_save_then_read_roundtrip(self):
        self.assertIn("已写入", self.tools.call(
            "save_file", '{"path": "t.txt", "content": "你好，小橙"}'))
        self.assertEqual(self.tools.call("read_file", '{"path": "t.txt"}'), "你好，小橙")

    def test_nested_directory_auto_created(self):
        self.assertIn("已写入", self.tools.call(
            "save_file", '{"path": "a/b/c.txt", "content": "深层目录"}'))
        self.assertEqual(self.tools.call("read_file", '{"path": "a/b/c.txt"}'), "深层目录")

    def test_long_result_truncated(self):
        """过长的结果必须截断，否则会撑爆上下文。而且要明确告知被截断了。"""
        self.tools.call("save_file", json.dumps({"path": "big.txt", "content": "啊" * 20000}))
        output = self.tools.call("read_file", '{"path": "big.txt"}')
        self.assertIn("已截断", output)
        self.assertLess(len(output), 5000)

    # ---- 错误处理 ----
    def test_unknown_tool_returns_error(self):
        self.assertIn("不存在", self.tools.call("launch_missiles", "{}"))

    def test_invalid_json_arguments(self):
        self.assertIn("不是合法的 JSON", self.tools.call("read_file", "{not json"))

    def test_wrong_argument_type(self):
        output = self.tools.call("calculator", '{"expression": 123}')
        self.assertTrue(output.startswith("错误"), output)

    def test_missing_required_argument(self):
        self.assertIn("参数不匹配", self.tools.call("read_file", "{}"))

    # ---- 知识库与记忆工具 ----
    def test_search_knowledge_tool(self):
        self.assertIn("520", self.tools.call(
            "search_knowledge", '{"query": "住宿报销标准", "top_k": 2}'))

    def test_memory_tools_roundtrip(self):
        self.assertIn("已记住", self.tools.call(
            "save_memory", '{"content": "用户小林，职级 P5", "category": "用户信息"}'))
        self.assertIn("P5", self.tools.call("recall_memory", '{"query": "职级"}'))


# ============================================================ 三、工具说明书自动生成
class TestSchemaGeneration(unittest.TestCase):
    """考察能否从函数本身自动推导出给模型看的 JSON 说明书。"""

    def test_docstring_becomes_description(self):
        def sample(argument):
            """这是功能说明。

            Args:
                argument: 这是参数说明
            """
            return argument

        schema = build_schema(sample)["function"]
        self.assertEqual(schema["name"], "sample")
        self.assertIn("这是功能说明", schema["description"])
        self.assertEqual(schema["parameters"]["properties"]["argument"]["description"],
                         "这是参数说明")
        self.assertEqual(schema["parameters"]["required"], ["argument"])

    def test_default_value_makes_optional(self):
        def sample(required_arg, optional_arg=3):
            """说明。"""
            return required_arg

        parameters = build_schema(sample)["function"]["parameters"]
        self.assertEqual(parameters["required"], ["required_arg"])
        self.assertEqual(parameters["properties"]["optional_arg"]["default"], 3)

    def test_type_mapping(self):
        def sample(text: str, count: int, ratio: float, flag: bool) -> str:
            """说明。"""
            return text

        properties = build_schema(sample)["function"]["parameters"]["properties"]
        self.assertEqual(properties["text"]["type"], "string")
        self.assertEqual(properties["count"]["type"], "integer")
        self.assertEqual(properties["ratio"]["type"], "number")
        self.assertEqual(properties["flag"]["type"], "boolean")

    def test_return_annotation_not_a_parameter(self):
        def sample(arg: str) -> int:
            """说明。"""
            return 1

        parameters = build_schema(sample)["function"]["parameters"]
        self.assertEqual(list(parameters["properties"].keys()), ["arg"])

    def test_registry_basics(self):
        registry = ToolRegistry()

        @registry.register
        def ping():
            """测试工具。"""
            return "pong"

        self.assertEqual(registry.names(), ["ping"])
        self.assertEqual(registry.call("ping", "{}"), "pong")
        self.assertEqual(len(registry.schemas()), 1)
        self.assertEqual(registry.describe()[0]["name"], "ping")


# ============================================================ 四、记忆
class TestShortTermMemory(unittest.TestCase):
    """考察会话内记忆与上下文裁剪。"""

    def test_system_prompt_always_first(self):
        memory = ShortTermMemory("你是助手")
        memory.add_user("你好")
        messages = memory.messages()
        self.assertEqual(messages[0]["role"], "system")
        self.assertEqual(messages[0]["content"], "你是助手")

    def test_truncation_keeps_most_recent(self):
        memory = ShortTermMemory("sys", budget_chars=100)
        for i in range(20):
            memory.add_user("第 {0} 条消息，内容足够长以便触发裁剪逻辑。".format(i))
        messages = memory.messages()
        self.assertLess(_total_chars(messages), 400)
        self.assertIn("第 19 条", json.dumps(messages, ensure_ascii=False))

    def test_truncation_is_announced(self):
        """裁剪历史必须明确告知模型，不能悄悄丢。"""
        memory = ShortTermMemory("sys", budget_chars=50)
        for i in range(10):
            memory.add_user("消息 {0} 内容内容内容内容内容".format(i))
        self.assertIn("已省略更早的", json.dumps(memory.messages(), ensure_ascii=False))

    def test_orphan_tool_message_removed(self):
        """落单的 tool 消息会被接口拒绝，必须清理掉。"""
        messages = ShortTermMemory._repair([
            {"role": "tool", "tool_call_id": "不存在的编号", "content": "x"},
            {"role": "user", "content": "你好"},
        ])
        self.assertEqual([m["role"] for m in messages], ["user"])

    def test_unanswered_tool_call_removed(self):
        """声明了工具调用却没有结果的消息，整条必须丢弃。"""
        messages = ShortTermMemory._repair([
            {"role": "assistant", "content": "",
             "tool_calls": [make_tool_call("f", {})]},
            {"role": "user", "content": "你好"},
        ])
        self.assertEqual([m["role"] for m in messages], ["user"])

    def test_matched_pairs_kept(self):
        call = make_tool_call("f", {}, "id-1")
        messages = ShortTermMemory._repair([
            {"role": "user", "content": "你好"},
            {"role": "assistant", "content": "", "tool_calls": [call]},
            {"role": "tool", "tool_call_id": "id-1", "content": "结果"},
            {"role": "assistant", "content": "完成"},
        ])
        self.assertEqual(len(messages), 4)

    def test_clear(self):
        memory = ShortTermMemory("sys")
        memory.add_user("你好")
        memory.clear()
        self.assertEqual(len(memory), 0)


def _total_chars(messages):
    return sum(len(str(m.get("content") or "")) for m in messages)


class TestLongTermMemory(unittest.TestCase):
    """考察跨会话记忆的持久化与检索。"""

    def setUp(self):
        self.temp_dir = tempfile.mkdtemp(prefix="agent-test-")
        self.path = os.path.join(self.temp_dir, "memory.json")

    def tearDown(self):
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_add_and_survive_restart(self):
        memory = LongTermMemory(self.path)
        self.assertIn("已记住", memory.add("用户小林，职级 P5"))
        self.assertTrue(os.path.isfile(self.path))

        reloaded = LongTermMemory(self.path)          # 模拟关掉程序再打开
        self.assertEqual(len(reloaded), 1)
        self.assertIn("小林", reloaded.recall("姓名 职级"))

    def test_duplicate_rejected(self):
        memory = LongTermMemory(self.path)
        memory.add("同一条事实")
        self.assertIn("已经在记忆里", memory.add("同一条事实"))
        self.assertEqual(len(memory), 1)

    def test_empty_content_rejected(self):
        self.assertIn("为空", LongTermMemory(self.path).add("   "))

    def test_recall_on_empty_memory(self):
        self.assertIn("为空", LongTermMemory(self.path).recall("任何东西"))

    def test_corrupted_file_does_not_crash(self):
        """记忆文件损坏时，应该当作"没有记忆"，而不是让整个 Agent 起不来。"""
        with open(self.path, "w", encoding="utf-8") as file:
            file.write("{ 这不是合法 JSON")
        memory = LongTermMemory(self.path)
        self.assertEqual(len(memory), 0)
        self.assertTrue(memory.corrupted)

    def test_reset(self):
        memory = LongTermMemory(self.path)
        memory.add("一些事实")
        memory.reset()
        self.assertEqual(len(memory), 0)
        self.assertFalse(os.path.isfile(self.path))


# ============================================================ 五、提示词
class TestPrompts(unittest.TestCase):
    """考察系统提示词的内容与一致性。"""

    def test_capabilities_match_enabled_flags(self):
        """开了什么能力，提示词里才会出现对应的工具名。"""
        full = build_system_prompt()
        self.assertIn("search_knowledge", full)
        self.assertIn("recall_memory", full)

        bare = build_system_prompt(has_knowledge=False, has_memory=False,
                                   has_calculator=False, has_files=False, has_time=False)
        for name in ("search_knowledge", "recall_memory", "save_memory",
                     "calculator", "get_time", "save_file"):
            self.assertNotIn(name, bare)

    def test_anti_hallucination_rule_present(self):
        prompt = build_system_prompt()
        self.assertIn("未找到相关信息", prompt)
        self.assertIn("禁止凭记忆", prompt)

    def test_security_redline_present(self):
        prompt = build_system_prompt()
        self.assertIn("安全红线", prompt)
        self.assertIn("API 密钥", prompt)

    def test_extra_rules_appended(self):
        prompt = build_system_prompt(extra_rules="回答必须以「青橙」两个字开头")
        self.assertIn("回答必须以「青橙」两个字开头", prompt)

    def test_agent_prompt_never_mentions_unregistered_tool(self):
        """
        核心不变量：系统提示词里提到的每个工具名，都必须真实注册过。

        声明了不存在的工具 → 模型会反复尝试调用，白白浪费轮次和费用
        隐藏了已有的工具   → 模型不知道该用，功能等于白做
        """
        temp_dir = tempfile.mkdtemp(prefix="agent-test-")
        try:
            agent = make_agent(temp_dir)
            known = ("search_knowledge", "recall_memory", "save_memory", "calculator",
                     "get_time", "save_file", "read_file", "list_dir")
            mentioned = {n for n in known if re.search(r"\b" + n + r"\b", agent.system_prompt)}
            registered = set(agent.tools.names())
            self.assertTrue(mentioned <= registered,
                            "提示词提到了未注册的工具：{0}".format(mentioned - registered))
            self.assertTrue(mentioned, "提示词一个工具都没提到，检查 build_system_prompt")
        finally:
            shutil.rmtree(temp_dir, ignore_errors=True)


# ============================================================ 六、Agent 主循环
class TestAgentLoop(unittest.TestCase):
    """考察编排循环的各个分支：正常完成、多轮工具、保险机制、异常兜底。"""

    def setUp(self):
        self.temp_dir = tempfile.mkdtemp(prefix="agent-test-")

    def tearDown(self):
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_direct_answer(self):
        """模型不调工具、直接给答案时，循环应当一轮就结束。"""
        agent = make_agent(self.temp_dir)
        agent.model.chat = scripted_model([
            {"role": "assistant", "content": "答案是 42"},
        ])
        result = agent.run("随便问点什么")
        self.assertEqual(result.status, "completed")
        self.assertEqual(result.answer, "答案是 42")
        self.assertEqual(result.tool_calls, [])
        self.assertTrue(result.ok)

    def test_single_tool_round(self):
        agent = make_agent(self.temp_dir)
        agent.model.chat = scripted_model([
            {"role": "assistant", "content": "",
             "tool_calls": [make_tool_call("calculator", {"expression": "6*7"}, "id1")]},
            {"role": "assistant", "content": "结果是 42"},
        ])
        result = agent.run("6 乘 7 等于几")
        self.assertTrue(result.ok)
        self.assertEqual(len(result.tool_calls), 1)
        self.assertEqual(result.tool_calls[0]["name"], "calculator")
        self.assertIn("42", result.tool_calls[0]["result"])

    def test_parallel_tool_calls(self):
        """模型可以一轮里同时点好几个工具，全部都要执行并回传。"""
        agent = make_agent(self.temp_dir)
        agent.model.chat = scripted_model([
            {"role": "assistant", "content": "", "tool_calls": [
                make_tool_call("get_time", {}, "a"),
                make_tool_call("calculator", {"expression": "1+1"}, "b"),
            ]},
            {"role": "assistant", "content": "完成"},
        ])
        result = agent.run("现在几点，顺便算 1+1")
        self.assertEqual([c["name"] for c in result.tool_calls], ["get_time", "calculator"])

    def test_max_steps_guard(self):
        """保险 1：永远只点菜不上菜的模型，必须被步数上限掐断。"""
        agent = make_agent(self.temp_dir, max_steps=3)
        agent.model.chat = scripted_model([
            {"role": "assistant", "content": "",
             "tool_calls": [make_tool_call("get_time", {}, "x")]},
        ])
        result = agent.run("死循环测试")
        self.assertEqual(result.status, "max_steps")
        self.assertIn("中止", result.answer)

    def test_duplicate_call_blocked(self):
        """保险 2：同样的工具 + 同样的参数，第二次必须被拦截。"""
        repeated = {"role": "assistant", "content": "",
                    "tool_calls": [make_tool_call("get_time", {}, "x")]}
        agent = make_agent(self.temp_dir, max_steps=4)
        agent.model.chat = scripted_model([
            repeated, repeated, {"role": "assistant", "content": "结束"},
        ])
        result = agent.run("重复调用测试")
        blocked = [c for c in result.tool_calls if "相同的参数" in c["result"]]
        self.assertTrue(blocked, "重复调用应该被拦截")

    def test_tool_error_fed_back_not_crash(self):
        """保险 3：工具报错不能让程序崩溃，错误文本要回传给模型让它自己纠错。"""
        agent = make_agent(self.temp_dir)
        agent.model.chat = scripted_model([
            {"role": "assistant", "content": "",
             "tool_calls": [make_tool_call("read_file", {"path": "../../.env"}, "id1")]},
            {"role": "assistant", "content": "抱歉，我无法读取该文件"},
        ])
        result = agent.run("读取 .env")
        self.assertTrue(result.ok)
        self.assertIn("权限拒绝", result.tool_calls[0]["result"])

    def test_unknown_tool_does_not_crash(self):
        agent = make_agent(self.temp_dir)
        agent.model.chat = scripted_model([
            {"role": "assistant", "content": "",
             "tool_calls": [make_tool_call("self_destruct", {}, "id1")]},
            {"role": "assistant", "content": "我没有这个能力"},
        ])
        result = agent.run("自毁")
        self.assertTrue(result.ok)
        self.assertIn("不存在", result.tool_calls[0]["result"])

    def test_model_error_handled(self):
        def broken(messages, tools=None):
            raise ModelError("模拟服务不可用")

        agent = make_agent(self.temp_dir)
        agent.model.chat = broken
        result = agent.run("任意任务")
        self.assertEqual(result.status, "error")
        self.assertIn("模拟服务不可用", result.answer)

    def test_empty_answer_marked(self):
        agent = make_agent(self.temp_dir)
        agent.model.chat = scripted_model([{"role": "assistant", "content": "   "}])
        self.assertEqual(agent.run("空回答测试").status, "empty")

    def test_trace_saved_without_secret(self):
        """轨迹必须落盘，且绝不能包含明文密钥。"""
        agent = make_agent(self.temp_dir)
        agent.model.chat = scripted_model([{"role": "assistant", "content": "好了"}])
        result = agent.run("轨迹测试")

        self.assertTrue(result.trace_path and os.path.isfile(result.trace_path))
        with open(result.trace_path, "r", encoding="utf-8") as file:
            raw = file.read()
        self.assertIn("轨迹测试", raw)
        if agent.config.api_key:
            self.assertNotIn(agent.config.api_key, raw)
            self.assertIn("*", json.loads(raw)["config"]["api_key"])

    def test_session_continuity(self):
        """同一个会话下，第二轮能看到第一轮的历史。"""
        captured = []

        def spy(messages, tools=None):
            captured.append(len(messages))
            return {"role": "assistant", "content": "收到"}, {"total_tokens": 5}

        agent = make_agent(self.temp_dir)
        agent.model.chat = spy
        session = agent.new_session()
        agent.run("我叫小林", session=session)
        agent.run("我职级 P5", session=session)
        self.assertGreater(captured[1], captured[0])

    def test_session_isolation(self):
        """不同会话之间历史互不干扰。"""
        captured = []

        def spy(messages, tools=None):
            captured.append(len(messages))
            return {"role": "assistant", "content": "收到"}, {"total_tokens": 5}

        agent = make_agent(self.temp_dir)
        agent.model.chat = spy
        agent.run("第一句")
        agent.run("第二句")
        self.assertEqual(captured[0], captured[1])

    def test_empty_session_not_replaced(self):
        """
        ShortTermMemory 实现了 __len__，所以一个空会话的布尔值是 False。
        判断"有没有传 session"必须用 is None，不能用 `session or 默认值`，
        否则传进来的空会话会被静默替换掉，多轮记忆完全失效且不报错。
        这条测试把这个行为永久锁死。
        """
        agent = make_agent(self.temp_dir)
        agent.model.chat = scripted_model([{"role": "assistant", "content": "收到"}])

        session = agent.new_session()
        self.assertEqual(len(session), 0)
        self.assertFalse(bool(session))          # 确认它确实是"假值"
        agent.run("第一句", session=session)
        self.assertGreater(len(session), 0)      # 但内容必须写进了原来那个对象

    def test_event_hook_receives_events(self):
        """事件钩子是把执行过程推给网页界面的基础。"""
        events = []
        agent = make_agent(self.temp_dir, on_event=events.append)
        agent.model.chat = scripted_model([
            {"role": "assistant", "content": "",
             "tool_calls": [make_tool_call("get_time", {}, "id1")]},
            {"role": "assistant", "content": "完成"},
        ])
        agent.run("事件钩子测试")
        kinds = [e["kind"] for e in events]
        for expected in ("task_start", "thinking", "tool", "answer", "task_end"):
            self.assertIn(expected, kinds)

    def test_broken_event_hook_does_not_break_agent(self):
        """日志或界面回调出错，绝不能影响主流程。"""
        def bad_hook(event):
            raise RuntimeError("回调炸了")

        agent = make_agent(self.temp_dir, on_event=bad_hook)
        agent.model.chat = scripted_model([{"role": "assistant", "content": "仍然成功"}])
        result = agent.run("回调异常测试")
        self.assertTrue(result.ok)
        self.assertEqual(result.answer, "仍然成功")

    def test_tool_manifest_matches_schemas(self):
        agent = make_agent(self.temp_dir)
        self.assertEqual(len(agent.tool_manifest()), len(agent.tools.schemas()))
        self.assertEqual({r["name"] for r in agent.tool_manifest()},
                         {"get_time", "calculator", "save_file", "read_file", "list_dir",
                          "search_knowledge", "save_memory", "recall_memory"})

    def test_disable_knowledge_removes_tool(self):
        """关掉知识库后，search_knowledge 工具不该存在，提示词里也不该提它。"""
        agent = make_agent(self.temp_dir)
        self.assertIn("search_knowledge", agent.tools.names())

        bare = Agent(config=Config(
            base_dir=self.temp_dir,
            AGENT_KB_DIR=KB_DIR,
            AGENT_WORKSPACE=os.path.join(self.temp_dir, "ws2"),
            AGENT_MEMORY_FILE=os.path.join(self.temp_dir, "m2.json"),
            AGENT_TRACE_DIR=os.path.join(self.temp_dir, "tr2")),
            use_knowledge=False, use_memory=False, offline=True)
        self.assertNotIn("search_knowledge", bare.tools.names())
        self.assertNotIn("search_knowledge", bare.system_prompt)


# ============================================================ 七、配置
class TestConfig(unittest.TestCase):
    """考察配置读取与安全打码。"""

    def test_snapshot_never_leaks_key(self):
        config = Config(base_dir=CODE_DIR)
        blob = json.dumps(config.public_snapshot(), ensure_ascii=False)
        if config.api_key:
            self.assertNotIn(config.api_key, blob)
            self.assertIn("*", config.public_snapshot()["api_key"])

    def test_defaults_are_sane(self):
        config = Config(base_dir=CODE_DIR)
        self.assertGreater(config.max_steps, 0)
        self.assertLessEqual(config.max_steps, 50)
        self.assertGreater(config.timeout, 0)
        self.assertGreater(config.context_budget, 0)

    def test_env_file_parsing(self):
        """验证 .env 解析：跳过注释与空行，去掉值两侧的引号。"""
        temp_dir = tempfile.mkdtemp(prefix="agent-test-")
        # 临时清空进程环境变量，避免外部注入的值盖住 .env（配置优先级：环境变量 > .env）
        saved = {k: os.environ.pop(k) for k in
                 ("AGENT_MODEL", "AGENT_MAX_STEPS", "AGENT_API_KEY", "AGENT_BASE_URL")
                 if k in os.environ}
        try:
            with open(os.path.join(temp_dir, ".env"), "w", encoding="utf-8") as file:
                file.write("# 这是注释\n\nAGENT_MODEL=\"测试模型\"\nAGENT_MAX_STEPS=3\n")
            config = Config(base_dir=temp_dir)
            self.assertEqual(config.model, "测试模型")
            self.assertEqual(config.max_steps, 3)
        finally:
            os.environ.update(saved)
            shutil.rmtree(temp_dir, ignore_errors=True)

    def test_process_env_beats_env_file(self):
        """配置优先级：系统环境变量高于 .env 文件。部署时用环境变量覆盖本地配置。"""
        temp_dir = tempfile.mkdtemp(prefix="agent-test-")
        saved = os.environ.get("AGENT_MODEL")
        try:
            with open(os.path.join(temp_dir, ".env"), "w", encoding="utf-8") as file:
                file.write("AGENT_MODEL=文件里的模型\n")
            os.environ["AGENT_MODEL"] = "环境变量里的模型"
            self.assertEqual(Config(base_dir=temp_dir).model, "环境变量里的模型")
        finally:
            if saved is None:
                os.environ.pop("AGENT_MODEL", None)
            else:
                os.environ["AGENT_MODEL"] = saved
            shutil.rmtree(temp_dir, ignore_errors=True)

    def test_overrides_win(self):
        config = Config(base_dir=CODE_DIR, AGENT_MODEL="覆盖模型", AGENT_MAX_STEPS="4")
        self.assertEqual(config.model, "覆盖模型")
        self.assertEqual(config.max_steps, 4)

    def test_offline_without_key(self):
        """没有密钥时应判定为离线，Agent 走试用模式而不是报错。"""
        temp_dir = tempfile.mkdtemp(prefix="agent-test-")
        try:
            config = Config(base_dir=temp_dir, AGENT_API_KEY="")
            # 空字符串会被当作"没有配置"，但环境变量里可能仍有值，
            # 所以这里只验证 online 属性与 api_key 的一致性
            self.assertEqual(config.online, bool(config.api_key))
        finally:
            shutil.rmtree(temp_dir, ignore_errors=True)


if __name__ == "__main__":
    unittest.main(verbosity=2)
