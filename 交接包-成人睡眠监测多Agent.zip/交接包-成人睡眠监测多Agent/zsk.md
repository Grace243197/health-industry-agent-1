数据已经非常充分了。现在我来综合整理输出完整的知识库架构对比分析。

---

# 📚 三大开源调研 Agent 知识库架构深度对比分析

---

## 一、各项目知识库架构详解

### 1. GPT Researcher（⭐ 30k+）

**架构类型：多源检索 + 上下文压缩管道（Retrieval + Compression Pipeline）**

```
用户查询
  │
  ▼
┌──────────────┐
│  Planner Agent│ ← 生成子问题列表
└──────┬───────┘
       │
       ▼
┌──────────────────────────────────────┐
│  Execution Agents (并行执行)          │
│  ┌─────────┐ ┌─────────┐ ┌────────┐ │
│  │Retriever│ │Scraper  │ │Context │ │
│  │(20+源)  │→│(爬取)   │→│Filter  │ │
│  └─────────┘ └─────────┘ └────────┘ │
└──────────────────┬───────────────────┘
                   │
                   ▼
          ┌────────────────┐
          │ Report Generator│
          └────────────────┘
```

**核心模块：**

| 模块 | 实现方式 | 说明 |
|:---|:---|:---|
| **检索器 (Retrievers)** | 插件化架构，20+ 检索后端 | Tavily（默认）、Google、Bing、Brave、DuckDuckGo、ArXiv、PubMed、Semantic Scholar、Exa（语义搜索）、SerpApi、Serper、MCP 等 |
| **向量存储 (Vector Store)** | `VectorStoreWrapper` — LangChain 适配层 | 数据库无关设计，支持任何 LangChain VectorStore 后端（Chroma/FAISS/Pinecone 等均可接入） |
| **分块策略** | `RecursiveCharacterTextSplitter` | chunk_size=1000, chunk_overlap=200 |
| **上下文压缩** | 三级压缩器 | ① `ContextCompressor`（嵌入相似度过滤，阈值 0.35）② `VectorstoreCompressor`（向量库直接检索）③ `WrittenContentCompressor`（已写章节压缩） |
| **Jev 过滤** | `jev_filter.py` + `lexical.py` | 基于 LLM 的相关性过滤，比纯 embedding 上下文相关性高 59% |
| **Smart Context** | 快速路径优化 | 内容 < 8000 字符时跳过压缩直接返回，节省 token |
| **数据源格式** | 本地文档支持 | PDF、Word、Excel、CSV、Markdown、PPT |

**优点：**
- ✅ 检索源最丰富（20+ 后端），覆盖学术、通用搜索、私有数据
- ✅ 插件化架构，扩展性极强，可自定义 retriever
- ✅ 上下文压缩管道成熟，有性能优化（快速路径）
- ✅ 数据库无关设计，不绑定特定向量库
- ✅ 多 agent 并行，效率高

**缺点：**
- ❌ 向量存储层较薄，本身不内置向量库，依赖 LangChain 生态
- ❌ 分块策略较简单（固定 1000/200），无自适应分块
- ❌ 无内置重排序模型（Cross-encoder），依赖 Jev（LLM 过滤，成本较高）
- ❌ 本地知识库场景偏弱，更侧重实时网络检索

---

### 2. Khoj（⭐ 38k+）

**架构类型：经典 RAG 管道（Bi-encoder 检索 + Cross-encoder 重排序）**

```
用户查询
  │
  ▼
┌─────────────────┐
│  Bi-encoder 检索 │ ← 查询→向量，与文档块向量做相似度匹配
│  (语义搜索)      │    置信度阈值过滤 (0.0~1.0)
└────────┬────────┘
         │ 候选文档块
         ▼
┌─────────────────┐
│ Cross-encoder   │ ← 精排，速度慢但质量高
│ 重排序           │    mixedbread-ai/mxbai-rerank-xsmall-v1
└────────┬────────┘
         │ 排序后结果
         ▼
┌─────────────────┐
│  LLM 生成回答    │
└─────────────────┘
```

**核心模块：**

| 模块 | 实现方式 | 说明 |
|:---|:---|:---|
| **嵌入模型 (Bi-encoder)** | 默认 `thenlper/gte-small` | 支持本地 SentenceTransformer / HuggingFace API / OpenAI API 三种部署模式 |
| **重排序模型 (Cross-encoder)** | 默认 `mixedbread-ai/mxbai-rerank-xsmall-v1` | 支持本地 / HuggingFace API 两种模式，Sigmoid 激活输出分数 |
| **向量数据库** | 未硬编码，抽象适配 | 通过配置指定，支持多种后端 |
| **文档处理器** | 按格式分模块 | PDF、Markdown、Org-mode、Notion、DOCX、GitHub、图片、纯文本 — 每种格式独立处理器 |
| **分块策略** | 文档块（chunks）| 索引前分割，具体参数未在文档中公开 |
| **检索管道** | 两阶段 | 第一阶段 Bi-encoder 粗排 → 第二阶段 Cross-encoder 精排 |
| **置信度阈值** | 可配置 0.0~1.0 | 控制返回文档数量，0.0=完全重叠，1.0=无意义 |
| **查询过滤** | 支持 | 可将搜索范围限制在特定条目内 |

**优点：**
- ✅ **经典双塔检索 + 精排架构**，学术界和工业界验证最充分的 RAG 范式
- ✅ 嵌入模型可灵活切换（本地/远程），换模型需重新索引
- ✅ 文档格式处理器丰富，尤其支持 Notion、Org-mode、GitHub 等知识管理工具
- ✅ 支持自托管，隐私友好，可在消费级硬件运行
- ✅ 重排序模型独立，检索质量高

**缺点：**
- ❌ 检索源单一，仅支持本地文档/笔记，**无网络搜索能力**
- ❌ 分块策略不透明，参数不可配置
- ❌ 换嵌入模型必须全量重新索引，迁移成本高
- ❌ 无多 agent 协作，纯单轮 RAG
- ❌ 不适合"行业调研"场景，更适合"个人知识库问答"

---

### 3. Alibaba DeepResearch / 通义深度研究（⭐ 20k+）

**架构类型：Agentic LLM + 工具调用（模型即 Agent，端到端训练）**

```
用户查询
  │
  ▼
┌──────────────────────────────────────┐
│  Tongyi-DeepResearch-30B-A3B         │
│  (MoE: 305亿总参/33亿激活)            │
│  128K 上下文                          │
│                                       │
│  ┌─────────────────────────────────┐ │
│  │  ReAct / IterResearch 推理循环   │ │
│  │  思考→行动→观察→思考→...         │ │
│  └──────────┬──────────────────────┘ │
│             │ 工具调用                 │
│  ┌──────────▼──────────────────────┐ │
│  │  工具层 (Tool Layer)             │ │
│  │  ┌──────┐ ┌──────┐ ┌─────────┐ │ │
│  │  │搜索   │ │网页   │ │文件解析  │ │ │
│  │  │Serper│ │Jina  │ │Dashscope│ │ │
│  │  │Google│ │.ai   │ │         │ │ │
│  │  │Scholar││Read  │ │Sandbox  │ │ │
│  │  └──────┘ └──────┘ └─────────┘ │ │
│  └─────────────────────────────────┘ │
└──────────────────────────────────────┘
```

**核心模块：**

| 模块 | 实现方式 | 说明 |
|:---|:---|:---|
| **基座模型** | Tongyi-DeepResearch-30B-A3B | MoE 架构，305 亿总参数，每 token 激活 33 亿，128K 上下文 |
| **推理范式** | ReAct + IterResearch "Heavy" 模式 | ReAct = 思考-行动-观察循环；IterResearch = 测试时扩展（test-time scaling），递归深入子主题 |
| **训练方法** | 两阶段 | ① 智能体中期训练（agentic mid-training）：大规模持续预训练 ② 智能体后期训练（agentic post-training）：端到端强化学习（Group Relative Policy Optimization） |
| **数据生成** | 全自动合成数据流水线 | 不依赖人工标注，自动生成训练数据 |
| **搜索工具** | Serper.dev | Google 搜索 + Google Scholar 学术搜索 |
| **网页阅读** | Jina.ai API | 网页内容提取 |
| **页面总结** | OpenAI 兼容 API | 摘要生成 |
| **文件解析** | Dashscope API | 文档解析 |
| **代码执行** | SandboxFusion | 沙箱代码运行 |
| **知识库** | `eval_data/file_corpus/` | 参考文件放在本地目录，通过文件名引用 |

**WebAgent 子系统（浏览器智能体集群）：**

| 子模块 | 功能 |
|:---|:---|
| WebResearcher | 网络研究 agent |
| WebWalker | 网页遍历 agent |
| WebSailor / WebSailor-V2 | 网页导航 agent |
| WebLeaper | 跳跃式检索 agent |
| WebShaper | 信息提取 agent |
| WebWeaver | 信息整合 agent |
| WebResummer | 摘要生成 agent |
| NestBrowse / ParallelMuse | 并行浏览 agent |

**优点：**
- ✅ **模型即 Agent**，端到端训练，工具调用能力内化到模型权重中，不是简单的 prompt 编排
- ✅ MoE 架构，推理效率高（仅激活 33 亿参数）
- ✅ 128K 超长上下文，可处理大量研究材料
- ✅ WebAgent 集群设计，多浏览器 agent 协作，模拟真实研究行为
- ✅ 训练方法先进（中期训练 + 强化学习），不依赖人工标注
- ✅ 有完整技术报告（arXiv 论文）支撑

**缺点：**
- ❌ **非传统 RAG 架构**，知识库概念弱化 — 更像一个"会搜索的 LLM"而非"知识库系统"
- ❌ 工具层依赖外部 API（Serper、Jina、Dashscope），离线/私有部署受限
- ❌ 本地知识库能力弱，文件仅作为评估语料，非索引检索
- ❌ 需要 GPU 推理资源（30B 参数模型），部署门槛高
- ❌ 不可插拔检索器，搜索能力由模型训练决定，无法灵活扩展数据源

---

## 二、横向对比表

| 维度 | GPT Researcher | Khoj | Alibaba DeepResearch |
|:---|:---|:---|:---|
| **架构范式** | 多源检索 + 压缩管道 | 经典双塔 RAG + 重排序 | Agentic LLM + 工具调用 |
| **核心理念** | "编排多个专家 agent" | "精确检索 + 精确排序" | "训练一个会搜索的模型" |
| **Star 数** | 30k+ | 38k+ | 20k+ |
| **向量数据库** | LangChain 适配（可选） | 可配置（未绑定） | 无内置向量库 |
| **嵌入模型** | 依赖 LangChain 生态 | gte-small（可换） | 模型内化，无独立嵌入 |
| **重排序** | Jev（LLM 过滤） | Cross-encoder（专用模型） | 模型自身注意力 |
| **分块策略** | 1000/200 固定 | 有分块（参数不透明） | 无分块（128K 直接吃） |
| **检索源数量** | **20+** | 仅本地文档 | Serper + Jina + Scholar |
| **网络搜索** | ✅ 核心能力 | ❌ 不支持 | ✅ 核心能力 |
| **本地文档** | ✅ 6+ 格式 | ✅ **8+ 格式（最丰富）** | ⚠️ 弱（评估语料） |
| **多 Agent 协作** | ✅ LangGraph/AG2 | ❌ 单轮 RAG | ✅ WebAgent 集群 |
| **隐私/自托管** | ✅ Docker/PIP | ✅ **消费级硬件可跑** | ⚠️ 需 GPU（30B 模型） |
| **可扩展性** | ✅ 插件化 retriever | ⚠️ 中等 | ❌ 需重新训练模型 |
| **上下文窗口** | 128K（GPT-4o） | 取决于 LLM | 128K（原生） |
| **许可证** | Apache 2.0 | AGPL-3.0 | Apache 2.0 |
| **学术支撑** | 150+ 论文引用 | 无论文 | arXiv 技术报告 |

---

## 三、纵向对比（架构演进视角）

```
第一代（传统 RAG）         第二代（编排式 RAG）        第三代（Agentic RAG）
━━━━━━━━━━━━━━         ━━━━━━━━━━━━━━         ━━━━━━━━━━━━━━━

   Khoj                   GPT Researcher           Alibaba DeepResearch
                           
 "检索→生成"              "规划→检索→过滤→生成"     "模型自主决策→工具调用"
                           
 固定管道                  可编排工作流               端到端训练
 单轮问答                  多轮深度研究               递归探索+自我修正
 本地知识库                多源融合                   模型内化知识
 嵌入+重排序               LLM过滤+压缩              强化学习优化
                           
 优点：稳定可控            优点：灵活可扩展           优点：自主性强
 缺点：场景单一            缺点：依赖prompt工程       缺点：需大量训练资源
```

---

## 四、适用场景推荐

| 场景 | 推荐项目 | 理由 |
|:---|:---|:---|
| **行业调研报告生成** | **GPT Researcher** | 20+ 检索源覆盖行业数据、财报、新闻；多 agent 并行效率高 |
| **个人/团队知识库问答** | **Khoj** | 本地文档处理能力强，隐私友好，可消费级硬件部署 |
| **深度学术研究** | **Alibaba DeepResearch** | 128K 上下文 + Scholar 搜索 + 递归深入，适合长周期研究 |
| **需要私有部署 + 网络调研** | **GPT Researcher** | Docker 部署 + 多检索源，兼顾安全与能力 |
| **预算有限 / 无 GPU** | **Khoj** 或 **GPT Researcher** | Khoj 可纯本地运行；GPT Researcher 可用 API 模式 |
| **追求最前沿技术** | **Alibaba DeepResearch** | 端到端训练 + MoE + 强化学习，技术栈最新 |

---

## 五、关键结论

1. **三者不是同一赛道的产品**：Khoj 是"知识库问答工具"，GPT Researcher 是"调研编排平台"，Alibaba DeepResearch 是"研究专用大模型"。
2. **知识库架构的核心分歧**：Khoj 和 GPT Researcher 都是"模型外"检索（RAG），区别在于 GPT Researcher 多了编排层和压缩层；Alibaba DeepResearch 走的是"模型内"路线，把检索能力训练进模型权重。
3. **做行业调研，GPT Researcher 最实用**：检索源最多、架构最灵活、社区最活跃、部署门槛适中。
4. **如果要做"行业调研 + 私有知识库"融合**，建议 GPT Researcher（网络调研）+ Khoj（私有知识）组合使用，或基于 GPT Researcher 的 MCP 协议接入私有数据。